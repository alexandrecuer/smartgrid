-- MySQL dump 10.17  Distrib 10.3.17-MariaDB, for debian-linux-gnueabihf (armv7l)
--
-- Host: localhost    Database: emoncms
-- ------------------------------------------------------
-- Server version	10.3.17-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_config` (
  `userid` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `height` int(11) DEFAULT 600,
  `name` varchar(30) DEFAULT 'no name',
  `alias` varchar(20) DEFAULT '',
  `description` varchar(255) DEFAULT 'no description',
  `main` tinyint(1) DEFAULT 0,
  `public` tinyint(1) DEFAULT 0,
  `published` tinyint(1) DEFAULT 0,
  `showdescription` tinyint(1) DEFAULT 0,
  `backgroundcolor` varchar(6) DEFAULT 'EDF7FC',
  `gridsize` tinyint(1) DEFAULT 20,
  `feedmode` varchar(8) DEFAULT 'feedid',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demandshaper`
--

DROP TABLE IF EXISTS `demandshaper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demandshaper` (
  `userid` int(11) DEFAULT NULL,
  `schedules` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demandshaper`
--

LOCK TABLES `demandshaper` WRITE;
/*!40000 ALTER TABLE `demandshaper` DISABLE KEYS */;
/*!40000 ALTER TABLE `demandshaper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `devicekey` varchar(64) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES (1,1,'Hioki8402','Hioki8402','','','',NULL),(2,1,'sofrel_Text','sofrel_Text','','','',NULL),(3,1,'sofrel_Tcascade','sofrel_Tcascade','','','',NULL),(4,1,'sofrel_Vantage','sofrel_Vantage','','','',NULL),(5,1,'sofrel_circuit_Cellule','sofrel_circuit_Cellule','','','',NULL),(6,1,'sofrel_circuit_Nord','sofrel_circuit_Nord','','','',NULL),(7,1,'sofrel_circuit_Sud','sofrel_circuit_Sud','','','',NULL),(8,1,'sofrel_circuit_SSHall','sofrel_circuit_SSHall','','','',NULL),(9,1,'sofrel_circuit_Est','sofrel_circuit_Est','','','',NULL),(10,1,'sofrel_circuit_Ouest','sofrel_circuit_Ouest','','','',NULL),(11,1,'TRH12211041_Cellule','TRH12211041_Cellule','','','',NULL),(12,1,'TRH12211184_Sud','TRH12211184_Sud','','','',NULL),(13,1,'TRH12211135_Nord','TRH12211135_Nord','','','',NULL),(14,1,'TRH12211196_Cellule2','TRH12211196_Cellule2','','','',NULL),(15,1,'sofrel_autopilot','sofrel_autopilot','','','',NULL),(16,1,'sofrel_courbe_chauffe','sofrel_courbe_chauffe','','','',NULL),(17,1,'sofrel_courbe_chauffe_admin','sofrel_courbe_chauffe_admin','','','',NULL);
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `datatype` int(11) NOT NULL,
  `public` tinyint(1) DEFAULT 0,
  `size` int(11) DEFAULT NULL,
  `engine` int(11) NOT NULL DEFAULT 0,
  `server` int(11) NOT NULL DEFAULT 0,
  `processList` text DEFAULT NULL,
  `unit` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (1,'Tcollecteur',1,'sofrel_Tcascade',NULL,NULL,1,0,4634760,5,0,NULL,''),(2,'Consigne',1,'sofrel_Tcascade',NULL,NULL,1,0,4634748,5,0,NULL,''),(3,'EtatC1',1,'sofrel_Tcascade',NULL,NULL,1,0,4634744,5,0,NULL,''),(4,'ConsigneC1',1,'sofrel_Tcascade',NULL,NULL,1,0,4634744,5,0,NULL,''),(5,'EtatC2',1,'sofrel_Tcascade',NULL,NULL,1,0,4634740,5,0,NULL,''),(6,'ConsigneC2',1,'sofrel_Tcascade',NULL,NULL,1,0,4634728,5,0,NULL,''),(7,'EtatC3',1,'sofrel_Tcascade',NULL,NULL,1,0,4634724,5,0,NULL,''),(8,'ConsigneC3',1,'sofrel_Tcascade',NULL,NULL,1,0,4634720,5,0,NULL,''),(9,'Text_nord',1,'sofrel_Text',NULL,NULL,1,0,4634716,5,0,NULL,''),(10,'Text_cellule',1,'sofrel_Text',NULL,NULL,1,0,4634716,5,0,NULL,''),(11,'Text_sud',1,'sofrel_Text',NULL,NULL,1,0,4634704,5,0,NULL,''),(12,'Text_hallssol',1,'sofrel_Text',NULL,NULL,1,0,4634684,5,0,NULL,''),(13,'Text_est',1,'sofrel_Text',NULL,NULL,1,0,4634680,5,0,NULL,''),(14,'Text_ouest',1,'sofrel_Text',NULL,NULL,1,0,4634680,5,0,NULL,''),(15,'VAN_pr_atm',1,'sofrel_Vantage',NULL,NULL,1,0,4634680,5,0,NULL,''),(16,'VAN_T_int',1,'sofrel_Vantage',NULL,NULL,1,0,4634660,5,0,NULL,''),(17,'VAN_HR_int',1,'sofrel_Vantage',NULL,NULL,1,0,4634656,5,0,NULL,''),(18,'VAN_Text',1,'sofrel_Vantage',NULL,NULL,1,0,4634636,5,0,NULL,''),(19,'VAN_HR_ext',1,'sofrel_Vantage',NULL,NULL,1,0,4634628,5,0,NULL,''),(20,'VAN_UV',1,'sofrel_Vantage',NULL,NULL,1,0,4634624,5,0,NULL,''),(21,'VAN_ray_sol',1,'sofrel_Vantage',NULL,NULL,1,0,4634608,5,0,NULL,'W/m2'),(22,'VAN_precip',1,'sofrel_Vantage',NULL,NULL,1,0,4634604,5,0,NULL,''),(23,'VAN_vitesse_vent',1,'sofrel_Vantage',NULL,NULL,1,0,4634588,5,0,NULL,''),(24,'VAN_precip_mmh',1,'sofrel_Vantage',NULL,NULL,1,0,4634588,5,0,NULL,''),(25,'Cellule_Tcircuit',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,4634584,5,0,NULL,'°C'),(26,'Cellule_Pompe',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,4634580,5,0,NULL,''),(27,'Cellule_V3V_FER',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,4634580,5,0,NULL,''),(28,'Cellule_V3V_OUV',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,4634568,5,0,NULL,''),(29,'cellules_TCretourcircuit',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,4634540,5,0,NULL,'°C'),(31,'Nord_Tcircuit',1,' sofrel_circuit_Nord',NULL,NULL,1,0,4632468,5,0,NULL,'°C'),(32,'Nord_Pompe',1,' sofrel_circuit_Nord',NULL,NULL,1,0,4632464,5,0,NULL,''),(33,'Nord_V3V_FER',1,' sofrel_circuit_Nord',NULL,NULL,1,0,4632464,5,0,NULL,''),(34,'Nord_V3V_OUV',1,' sofrel_circuit_Nord',NULL,NULL,1,0,4632464,5,0,NULL,''),(35,'Nord_TCretourcircuit',1,' sofrel_circuit_Nord',NULL,NULL,1,0,4632452,5,0,NULL,'°C'),(36,'Sud_Tcircuit',1,' sofrel_circuit_Sud',NULL,NULL,1,0,4632388,5,0,NULL,'°C'),(37,'Sud_Pompe',1,' sofrel_circuit_Sud',NULL,NULL,1,0,4632384,5,0,NULL,''),(38,'Sud_V3V_FER',1,' sofrel_circuit_Sud',NULL,NULL,1,0,4632384,5,0,NULL,''),(39,'Sud_V3V_OUV',1,' sofrel_circuit_Sud',NULL,NULL,1,0,4632380,5,0,NULL,''),(40,'Sud_TCretourcircuit',1,' sofrel_circuit_Sud',NULL,NULL,1,0,4632352,5,0,NULL,'°C'),(64,'cellules_instpower',1,'Virtual',NULL,NULL,1,0,0,7,0,'53:25,56:29,process__min_value_allowed:0,2:1162.5,2:5.19','W'),(63,'Cellules_Kwh_acc',1,'from_postprocess',NULL,NULL,1,0,4427908,5,0,NULL,'kWh'),(45,'temp',1,'TRH12211041_Cellule',NULL,NULL,1,0,142808,5,0,NULL,''),(46,'RSSI',1,'TRH12211041_Cellule',NULL,NULL,1,0,142792,5,0,NULL,''),(47,'RSSI',1,'TRH12211184_Sud',NULL,NULL,1,0,142792,5,0,NULL,''),(48,'temp',1,'TRH12211184_Sud',NULL,NULL,1,0,130152,5,0,NULL,''),(49,'Timer',1,'TRH12211041_Cellule',NULL,NULL,1,0,139264,5,0,NULL,''),(50,'Timer',1,'TRH12211184_Sud',NULL,NULL,1,0,139264,5,0,NULL,''),(51,'temp',1,'TRH12211135_Nord',NULL,NULL,1,0,131384,5,0,NULL,''),(52,'Timer',1,'TRH12211135_Nord',NULL,NULL,1,0,131384,5,0,NULL,''),(53,'RSSI',1,'TRH12211135_Nord',NULL,NULL,1,0,131384,5,0,NULL,''),(54,'RSSI',1,'TRH12211196_Cellule2',NULL,NULL,1,0,130468,5,0,NULL,''),(55,'Timer',1,'TRH12211196_Cellule2',NULL,NULL,1,0,130468,5,0,NULL,''),(56,'temp',1,'TRH12211196_Cellule2',NULL,NULL,1,0,130444,5,0,NULL,''),(57,'cellule',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(58,'nord',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(59,'sud',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(60,'sous-sol',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(61,'est',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(62,'ouest',1,'sofrel_autopilot',NULL,NULL,1,0,129256,5,0,NULL,''),(70,'CSud_power_W',1,'power',NULL,NULL,1,0,4632348,5,0,NULL,'W'),(66,'cellules_power_W',1,'power',NULL,NULL,1,0,4631896,5,0,NULL,'W'),(68,'CNord_power_W',1,'power',NULL,NULL,1,0,4632328,5,0,NULL,'W');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT 0,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph`
--

LOCK TABLES `graph` WRITE;
/*!40000 ALTER TABLE `graph` DISABLE KEYS */;
INSERT INTO `graph` VALUES (1,1,0,'{\"name\":\"circuit_cellule\",\"start\":1577185200000,\"end\":1577790900000,\"interval\":900,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":26,\"name\":\"Cellule_Pompe\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#efda87\"},{\"id\":27,\"name\":\"Cellule_V3V_FER\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#000000\"},{\"id\":28,\"name\":\"Cellule_V3V_OUV\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":29,\"name\":\"cellules_TCretourcircuit\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ffff\"},{\"id\":25,\"name\":\"Cellule_Tcircuit\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff0000\"},{\"id\":18,\"name\":\"VAN_Text\",\"tag\":\"sofrel_Vantage\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ff80\"},{\"id\":43,\"name\":\"temp_cellule1\",\"tag\":\"TRH12220020\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8040\"},{\"id\":42,\"name\":\"temp_ext\",\"tag\":\"TEXT12310257\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#00ff80\"},{\"id\":45,\"name\":\"temp\",\"tag\":\"TRH12211041_Cellule\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8040\"},{\"id\":56,\"name\":\"temp\",\"tag\":\"TRH12211196_Cellule2\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8040\"}],\"id\":\"1\"}'),(2,1,0,'{\"name\":\"circuit_nord\",\"start\":1577202300000,\"end\":1577808000000,\"interval\":900,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":32,\"name\":\"Nord_Pompe\",\"tag\":\" sofrel_circuit_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#efda87\"},{\"id\":34,\"name\":\"Nord_V3V_OUV\",\"tag\":\" sofrel_circuit_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":33,\"name\":\"Nord_V3V_FER\",\"tag\":\" sofrel_circuit_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#000000\"},{\"id\":31,\"name\":\"Nord_Tcircuit\",\"tag\":\" sofrel_circuit_Nord\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff0000\"},{\"id\":35,\"name\":\"Nord_TCretourcircuit\",\"tag\":\" sofrel_circuit_Nord\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ffff\"},{\"id\":18,\"name\":\"VAN_Text\",\"tag\":\"sofrel_Vantage\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8000\"},{\"id\":51,\"name\":\"temp\",\"tag\":\"TRH12211135_Nord\",\"yaxis\":2,\"fill\":0,\"scale\":1,\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"2\"}'),(3,1,0,'{\"name\":\"circuit_sud\",\"start\":1577202300000,\"end\":1577808000000,\"interval\":900,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":37,\"name\":\"Sud_Pompe\",\"tag\":\" sofrel_circuit_Sud\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#efda87\"},{\"id\":39,\"name\":\"Sud_V3V_OUV\",\"tag\":\" sofrel_circuit_Sud\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":38,\"name\":\"Sud_V3V_FER\",\"tag\":\" sofrel_circuit_Sud\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#000000\"},{\"id\":36,\"name\":\"Sud_Tcircuit\",\"tag\":\" sofrel_circuit_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff0000\"},{\"id\":40,\"name\":\"Sud_TCretourcircuit\",\"tag\":\" sofrel_circuit_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":18,\"name\":\"VAN_Text\",\"tag\":\"sofrel_Vantage\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ff80\"},{\"id\":48,\"name\":\"temp\",\"tag\":\"TRH12211184_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8040\"}],\"id\":\"3\"}'),(8,1,0,'{\"name\":\"rayonnement_solaire\",\"start\":1575452700000,\"end\":1576058400000,\"interval\":900,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":20,\"name\":\"VAN_UV\",\"tag\":\"sofrel_Vantage\",\"yaxis\":2,\"fill\":true,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#800080\"},{\"id\":21,\"name\":\"VAN_ray_sol\",\"tag\":\"sofrel_Vantage\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#efda87\"}],\"id\":\"\"}'),(9,1,0,'{\"name\":\"RSSI\",\"start\":1577699400000,\"end\":1577785920000,\"interval\":120,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"0\",\"yaxismax\":\"20\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":47,\"name\":\"RSSI\",\"tag\":\"TRH12211184_Sud\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":53,\"name\":\"RSSI\",\"tag\":\"TRH12211135_Nord\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ffff\"},{\"id\":46,\"name\":\"RSSI\",\"tag\":\"TRH12211041_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ff80\"},{\"id\":50,\"name\":\"Timer\",\"tag\":\"TRH12211184_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":52,\"name\":\"Timer\",\"tag\":\"TRH12211135_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":49,\"name\":\"Timer\",\"tag\":\"TRH12211041_Cellule\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ff80\"},{\"id\":55,\"name\":\"Timer\",\"tag\":\"TRH12211196_Cellule2\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ffb468\"},{\"id\":54,\"name\":\"RSSI\",\"tag\":\"TRH12211196_Cellule2\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ffb468\"}],\"id\":\"9\"}'),(10,1,0,'{\"name\":\"indoor temps\",\"start\":1577202300000,\"end\":1577808000000,\"interval\":900,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":45,\"name\":\"temp\",\"tag\":\"TRH12211041_Cellule\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":48,\"name\":\"temp\",\"tag\":\"TRH12211184_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":51,\"name\":\"temp\",\"tag\":\"TRH12211135_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":56,\"name\":\"temp\",\"tag\":\"TRH12211196_Cellule2\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}'),(7,1,0,'{\"name\":\"cascade_chaudieres\",\"start\":1577720760000,\"end\":1577807280000,\"interval\":120,\"limitinterval\":0,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":7,\"name\":\"EtatC3\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#ffcaff\"},{\"id\":5,\"name\":\"EtatC2\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#ffb0b0\"},{\"id\":3,\"name\":\"EtatC1\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true,\"color\":\"#c0c0c0\"},{\"id\":8,\"name\":\"ConsigneC3\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff80ff\"},{\"id\":6,\"name\":\"ConsigneC2\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff0000\"},{\"id\":4,\"name\":\"ConsigneC1\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#000000\"},{\"id\":1,\"name\":\"Tcollecteur\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#80ff80\"},{\"id\":18,\"name\":\"VAN_Text\",\"tag\":\"sofrel_Vantage\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#0080ff\"},{\"id\":2,\"name\":\"Consigne\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ddb71e\"}],\"id\":\"7\"}'),(11,1,0,'{\"name\":\"cellules_puissance\",\"start\":1575738000000,\"end\":1586844000000,\"interval\":18000,\"fixinterval\":false,\"floatingtime\":0,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":64,\"name\":\"testing virtual feeds\",\"tag\":\"Virtual\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"delta\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":25,\"name\":\"Cellule_Tcircuit\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":29,\"name\":\"cellules_TCretourcircuit\",\"tag\":\" sofrel_circuit_Cellule\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}');
/*!40000 ALTER TABLE `graph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `processList` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `input`
--

LOCK TABLES `input` WRITE;
/*!40000 ALTER TABLE `input` DISABLE KEYS */;
INSERT INTO `input` VALUES (1,1,'Hioki8402','TC1','','1:29',NULL,NULL),(2,1,'Hioki8402','TC2','','1:35',NULL,NULL),(3,1,'Hioki8402','TC3','','1:40',NULL,NULL),(4,1,'sofrel_Text','Text_nord','','1:9',NULL,NULL),(5,1,'sofrel_Text','Text_cellule','','1:10',NULL,NULL),(6,1,'sofrel_Text','Text_sud','','1:11',NULL,NULL),(7,1,'sofrel_Text','Text_hallssol','','1:12',NULL,NULL),(8,1,'sofrel_Text','Text_est','','1:13',NULL,NULL),(9,1,'sofrel_Text','Text_ouest','','1:14',NULL,NULL),(10,1,'sofrel_Tcascade','Tcollecteur','','1:1',NULL,NULL),(11,1,'sofrel_Tcascade','Consigne','','1:2',NULL,NULL),(12,1,'sofrel_Tcascade','EtatC1','','1:3',NULL,NULL),(13,1,'sofrel_Tcascade','ConsigneC1','','1:4',NULL,NULL),(14,1,'sofrel_Tcascade','EtatC2','','1:5',NULL,NULL),(15,1,'sofrel_Tcascade','ConsigneC2','','1:6',NULL,NULL),(16,1,'sofrel_Tcascade','EtatC3','','1:7',NULL,NULL),(17,1,'sofrel_Tcascade','ConsigneC3','','1:8',NULL,NULL),(18,1,'sofrel_Vantage','VAN_pr_atm','','1:15',NULL,NULL),(19,1,'sofrel_Vantage','VAN_T_int','','1:16',NULL,NULL),(20,1,'sofrel_Vantage','VAN_HR_int','','1:17',NULL,NULL),(21,1,'sofrel_Vantage','VAN_Text','','1:18',NULL,NULL),(22,1,'sofrel_Vantage','VAN_HR_ext','','1:19',NULL,NULL),(23,1,'sofrel_Vantage','VAN_UV','','1:20',NULL,NULL),(24,1,'sofrel_Vantage','VAN_ray_sol','','1:21',NULL,NULL),(25,1,'sofrel_Vantage','VAN_precip','','1:22',NULL,NULL),(26,1,'sofrel_Vantage','VAN_vitesse_vent','','1:23',NULL,NULL),(27,1,'sofrel_Vantage','VAN_precip_mmh','','1:24',NULL,NULL),(28,1,'sofrel_circuit_Cellule','Cellule_Tcircuit','','1:25',NULL,NULL),(29,1,'sofrel_circuit_Cellule','Cellule_Pompe','','1:26',NULL,NULL),(30,1,'sofrel_circuit_Cellule','Cellule_V3V_FER','','1:27',NULL,NULL),(31,1,'sofrel_circuit_Cellule','Cellule_V3V_OUV','','1:28',NULL,NULL),(32,1,'sofrel_circuit_Nord','Nord_Tcircuit','','1:31',NULL,NULL),(33,1,'sofrel_circuit_Nord','Nord_Pompe','','1:32',NULL,NULL),(34,1,'sofrel_circuit_Nord','Nord_V3V_FER','','1:33',NULL,NULL),(35,1,'sofrel_circuit_Nord','Nord_V3V_OUV','','1:34',NULL,NULL),(36,1,'sofrel_circuit_Sud','Sud_Tcircuit','','1:36',NULL,NULL),(37,1,'sofrel_circuit_Sud','Sud_Pompe','','1:37',NULL,NULL),(38,1,'sofrel_circuit_Sud','Sud_V3V_FER','','1:38',NULL,NULL),(39,1,'sofrel_circuit_Sud','Sud_V3V_OUV','','1:39',NULL,NULL),(40,1,'sofrel_circuit_SSHall','SSHall_Tcircuit','','',NULL,NULL),(41,1,'sofrel_circuit_SSHall','SSHall_Pompe','','',NULL,NULL),(42,1,'sofrel_circuit_SSHall','SSHall_V3V_FER','','',NULL,NULL),(43,1,'sofrel_circuit_SSHall','SSHal_V3V_OUV','','',NULL,NULL),(44,1,'sofrel_circuit_Est','Est_Tcircuit','','',NULL,NULL),(45,1,'sofrel_circuit_Est','Est_Pompe','','',NULL,NULL),(46,1,'sofrel_circuit_Est','Est_V3V_FER','','',NULL,NULL),(47,1,'sofrel_circuit_Est','Est_V3V_OUV','','',NULL,NULL),(48,1,'sofrel_circuit_Ouest','Ouest_Tcircuit','','',NULL,NULL),(49,1,'sofrel_circuit_Ouest','Ouest_Pompe','','',NULL,NULL),(50,1,'sofrel_circuit_Ouest','Ouest_V3V_FER','','',NULL,NULL),(51,1,'sofrel_circuit_Ouest','Ouest_V3V_OUV','','',NULL,NULL),(52,1,'TRH12211041_Cellule','SlaveType','','',NULL,NULL),(53,1,'TRH12211041_Cellule','Timer','','1:49',NULL,NULL),(54,1,'TRH12211041_Cellule','RSSI','','1:46',NULL,NULL),(55,1,'TRH12211041_Cellule','serHigh','','',NULL,NULL),(56,1,'TRH12211041_Cellule','serLow','','',NULL,NULL),(57,1,'TRH12211041_Cellule','temp','','1:45',NULL,NULL),(58,1,'TRH12211041_Cellule','hum','','',NULL,NULL),(59,1,'TRH12211184_Sud','SlaveType','','',NULL,NULL),(60,1,'TRH12211184_Sud','Timer','','1:50',NULL,NULL),(61,1,'TRH12211184_Sud','RSSI','','1:47',NULL,NULL),(62,1,'TRH12211184_Sud','serHigh','','',NULL,NULL),(63,1,'TRH12211184_Sud','serLow','','',NULL,NULL),(64,1,'TRH12211184_Sud','temp','','1:48',NULL,NULL),(65,1,'TRH12211184_Sud','hum','','',NULL,NULL),(66,1,'TRH12211135_Nord','SlaveType','','',NULL,NULL),(67,1,'TRH12211135_Nord','Timer','','1:52',NULL,NULL),(68,1,'TRH12211135_Nord','RSSI','','1:53',NULL,NULL),(69,1,'TRH12211135_Nord','serHigh','','',NULL,NULL),(70,1,'TRH12211135_Nord','serLow','','',NULL,NULL),(71,1,'TRH12211135_Nord','temp','','1:51',NULL,NULL),(72,1,'TRH12211135_Nord','hum','','',NULL,NULL),(73,1,'TRH12211196_Cellule2','SlaveType','','',NULL,NULL),(74,1,'TRH12211196_Cellule2','Timer','','1:55',NULL,NULL),(75,1,'TRH12211196_Cellule2','RSSI','','1:54',NULL,NULL),(76,1,'TRH12211196_Cellule2','serHigh','','',NULL,NULL),(77,1,'TRH12211196_Cellule2','serLow','','',NULL,NULL),(78,1,'TRH12211196_Cellule2','temp','','1:56',NULL,NULL),(79,1,'TRH12211196_Cellule2','hum','','',NULL,NULL),(80,1,'sofrel_autopilot','cellule','','1:57',NULL,NULL),(81,1,'sofrel_autopilot','nord','','1:58',NULL,NULL),(82,1,'sofrel_autopilot','sud','','1:59',NULL,NULL),(83,1,'sofrel_autopilot','sous-sol','','1:60',NULL,NULL),(84,1,'sofrel_autopilot','est','','1:61',NULL,NULL),(85,1,'sofrel_autopilot','ouest','','1:62',NULL,NULL),(92,1,'sofrel_courbe_chauffe','NordTdep20','','',NULL,NULL),(93,1,'sofrel_courbe_chauffe','NordTref','','',NULL,NULL),(89,1,'sofrel_courbe_chauffe','cellTdep20','','',NULL,NULL),(90,1,'sofrel_courbe_chauffe','cellTref','','',NULL,NULL),(91,1,'sofrel_courbe_chauffe','cellTdepref','','',NULL,NULL),(94,1,'sofrel_courbe_chauffe','NordTdepref','','',NULL,NULL),(95,1,'sofrel_courbe_chauffe','SudTdep20','','',NULL,NULL),(96,1,'sofrel_courbe_chauffe','SudTref','','',NULL,NULL),(97,1,'sofrel_courbe_chauffe','SudTdepref','','',NULL,NULL),(98,1,'sofrel_courbe_chauffe_admin','hallTdep20','','',NULL,NULL),(99,1,'sofrel_courbe_chauffe_admin','hallTref','','',NULL,NULL),(100,1,'sofrel_courbe_chauffe_admin','hallTdepref','','',NULL,NULL),(101,1,'sofrel_courbe_chauffe_admin','estTdep20','','',NULL,NULL),(102,1,'sofrel_courbe_chauffe_admin','estTref','','',NULL,NULL),(103,1,'sofrel_courbe_chauffe_admin','estTdepref','','',NULL,NULL),(104,1,'sofrel_courbe_chauffe_admin','ouestTdep20','','',NULL,NULL),(105,1,'sofrel_courbe_chauffe_admin','ouestTref','','',NULL,NULL),(106,1,'sofrel_courbe_chauffe_admin','ouestTdepref','','',NULL,NULL);
/*!40000 ALTER TABLE `input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multigraph`
--

DROP TABLE IF EXISTS `multigraph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multigraph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `feedlist` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multigraph`
--

LOCK TABLES `multigraph` WRITE;
/*!40000 ALTER TABLE `multigraph` DISABLE KEYS */;
/*!40000 ALTER TABLE `multigraph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postprocess`
--

DROP TABLE IF EXISTS `postprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postprocess` (
  `userid` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postprocess`
--

LOCK TABLES `postprocess` WRITE;
/*!40000 ALTER TABLE `postprocess` DISABLE KEYS */;
INSERT INTO `postprocess` VALUES (1,'[{\"vhc\":\"1162.5\",\"flow\":\"5.19\",\"tint\":25,\"text\":29,\"output\":63,\"process\":\"constantflow_tokwh\"},{\"formula\":\"1162.5*5.19*max(f25-f29,0)\",\"output\":66,\"process\":\"basic_formula\"},{\"formula\":\"1162.5*6.5*max(f31-f35,0)\",\"output\":68,\"process\":\"basic_formula\"},{\"formula\":\"1162.5*4.2*max(f36-f40,0)\",\"output\":70,\"process\":\"basic_formula\"}]');
/*!40000 ALTER TABLE `postprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rememberme`
--

DROP TABLE IF EXISTS `rememberme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme` (
  `userid` int(11) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `persistentToken` varchar(40) DEFAULT NULL,
  `expire` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme`
--

LOCK TABLES `rememberme` WRITE;
/*!40000 ALTER TABLE `rememberme` DISABLE KEYS */;
INSERT INTO `rememberme` VALUES (1,'c0043ea3d59faa3e7222a49654d6513a1e977d83','b6e14473ec70ffe5200a1e30b2bd4c2637cfd3f9','2020-05-17 09:16:40');
/*!40000 ALTER TABLE `rememberme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `expression` text DEFAULT NULL,
  `timezone` varchar(64) DEFAULT 'UTC',
  `public` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup`
--

DROP TABLE IF EXISTS `setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup` (
  `state` varchar(32) DEFAULT 'unconfigured',
  `wifi` varchar(32) DEFAULT 'unconfigured'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup`
--

LOCK TABLES `setup` WRITE;
/*!40000 ALTER TABLE `setup` DISABLE KEYS */;
INSERT INTO `setup` VALUES ('unconfigured','ethernet');
/*!40000 ALTER TABLE `setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync`
--

DROP TABLE IF EXISTS `sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync` (
  `userid` int(11) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync`
--

LOCK TABLES `sync` WRITE;
/*!40000 ALTER TABLE `sync` DISABLE KEYS */;
INSERT INTO `sync` VALUES (1,'http://ceremace.ddns.net','alexandrecuer','5667ff245edc126177b6a8cdcf616e97','6f8c3270fb298877ab481841e3234bd1');
/*!40000 ALTER TABLE `sync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL,
  `gravatar` varchar(30) DEFAULT '',
  `name` varchar(30) DEFAULT '',
  `location` varchar(30) DEFAULT '',
  `timezone` varchar(64) DEFAULT 'UTC',
  `language` varchar(5) DEFAULT 'en_EN',
  `bio` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `startingpage` varchar(64) DEFAULT 'feed/list',
  `email_verified` int(11) DEFAULT 0,
  `verification_key` varchar(64) DEFAULT '',
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'alexandrecuer','alexandre.cuer@cerema.fr','fb88b9bd92628a263fadffd38f2241cdaa599c601f9c83aa93adc99397f96ee3','7b2e6a517f3d8c6f153a812aa9b7f7b9','9237c4290003ddb9c240730eecc9d4ff','8f87b1d04209ac8771a688c86ae245c9',NULL,1,'','','','Europe/Paris','en_EN','','','feed/list',0,'','{\"0\":false,\"bookmarks\":[{\"path\":\"feed\\/list\",\"text\":\"Feeds\"}]}');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-22 16:05:47
