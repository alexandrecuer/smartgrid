/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for Linux (armv8l)
--
-- Host: localhost    Database: emoncms
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `height` int(11) DEFAULT 600,
  `name` varchar(30) DEFAULT 'no name',
  `alias` varchar(20) DEFAULT '',
  `description` varchar(255) DEFAULT 'no description',
  `main` tinyint(1) DEFAULT 0,
  `public` tinyint(1) DEFAULT 0,
  `published` tinyint(1) DEFAULT 0,
  `showdescription` tinyint(1) DEFAULT 0,
  `backgroundcolor` varchar(6) DEFAULT 'EDF7FC',
  `gridsize` tinyint(1) DEFAULT 20,
  `fullscreen` tinyint(1) DEFAULT 0,
  `feedmode` varchar(8) DEFAULT 'feedid',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
INSERT INTO `dashboard` VALUES
(1,1,'<div id=\"1\" class=\"thermometer\" style=\"position:absolute; margin: 0; top:40px; left:100px; width:160px; height:200px;\" titlethermometer=\"temp accueil\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"48\" min=\"15\" max=\"26\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"10\" displayminmax=\"1\" minvaluefeed=\"36\" maxvaluefeed=\"36\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-1\" width=\"160\" height=\"200\"></canvas><div id=\"can-1-tooltip-1\"></div><div id=\"can-1-tooltip-2\"></div></div><div id=\"2\" class=\"psychrograph\" style=\"position: absolute; margin: 0px; top: 20px; left: 340px; width: 660px; height: 940px;\" mid=\"1\" hrtohabs=\"1\" givoni=\"0\"><iframe frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/vis/psychrograph?embed=1&mid=1&hrtohabs=1&givoni=0\" style=\"width: 660px; height: 940px;\"></iframe></div>',960,'INFOMA','infoma','no description',0,1,1,0,'edf7fc',20,0,'feedid');
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `datatype` int(11) NOT NULL,
  `public` tinyint(1) DEFAULT 0,
  `size` int(11) DEFAULT NULL,
  `engine` int(11) NOT NULL DEFAULT 0,
  `server` int(11) NOT NULL DEFAULT 0,
  `processList` text DEFAULT NULL,
  `unit` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES
(1,'outdoor_temp_C',1,'OWM_infoma',NULL,NULL,1,1,435720,5,0,NULL,'°C'),
(2,'outdoor_pressure_hPa',1,'OWM_infoma',NULL,NULL,1,0,435720,5,0,NULL,'hPa'),
(3,'outdoor_humidity_percent',1,'OWM_infoma',NULL,NULL,1,0,435720,5,0,NULL,'%'),
(4,'outdoor_wind_speed_ms',1,'OWM_infoma',NULL,NULL,1,0,435720,5,0,NULL,'m/s'),
(5,'outdoor_wind_deg',1,'OWM_infoma',NULL,NULL,1,0,435720,5,0,NULL,'deg'),
(6,'outdoor_clouds_all_percent',1,'OWM_infoma',NULL,NULL,1,0,435720,5,0,NULL,'%'),
(7,'temp',1,'BAT-C_RDC_BUR-3_NE',NULL,NULL,1,0,93356,5,0,NULL,'°C'),
(8,'rh',1,'BAT-C_RDC_BUR-3_NE',NULL,NULL,1,0,93356,5,0,NULL,'%'),
(9,'temp',1,'BAT-C_1ER_BUR-14_SO',NULL,NULL,1,0,93344,5,0,NULL,'°C'),
(10,'rh',1,'BAT-C_1ER_BUR-14_SO',NULL,NULL,1,0,93344,5,0,NULL,'%'),
(11,'temp',1,'BAT-C_1ER_BUR-27_SE',NULL,NULL,1,0,93280,5,0,NULL,'°C'),
(12,'temp_12220777',1,'BAT-C_RDC_BUR-6_NE',NULL,NULL,1,0,93348,5,0,NULL,'°C'),
(13,'rh',1,'BAT-C_RDC_BUR-6_NE',NULL,NULL,1,0,93348,5,0,NULL,'%'),
(14,'rh',1,'BAT-C_1ER_BUR-27_SE',NULL,NULL,1,0,93348,5,0,NULL,'%'),
(15,'temp',1,'BAT-C_RDC_CRS-9_SE',NULL,NULL,1,0,93340,5,0,NULL,'°C'),
(16,'rh',1,'BAT-C_RDC_CRS-9_SE',NULL,NULL,1,0,93340,5,0,NULL,'%'),
(17,'temp',1,'BAT-C_RDC_BUR-7_SO',NULL,NULL,1,0,93340,5,0,NULL,'°C'),
(18,'rh',1,'BAT-C_RDC_BUR-7_SO',NULL,NULL,1,0,93340,5,0,NULL,'%'),
(19,'temp_12220783',1,'BAT-C_RDC_BUR-12_SO',NULL,NULL,1,0,93340,5,0,NULL,'°C'),
(20,'rh',1,'BAT-C_RDC_BUR-12_SO',NULL,NULL,1,0,93340,5,0,NULL,'%'),
(23,'CO2',1,'BAT-C_RDC_CRS-7_NO',NULL,NULL,1,0,31116,5,0,NULL,'ppm'),
(24,'temp',1,'BAT-C_1ER_BUR-22_SE',NULL,NULL,1,0,93336,5,0,NULL,'°C'),
(25,'rh',1,'BAT-C_1ER_BUR-21_NO',NULL,NULL,1,0,93324,5,0,NULL,'%'),
(26,'temp',1,'BAT-C_1ER_BUR-21_NO',NULL,NULL,1,0,93324,5,0,NULL,'°C'),
(27,'rh',1,'BAT-C_1ER_BUR-22_SE',NULL,NULL,1,0,93336,5,0,NULL,'%'),
(28,'temp_12220064',1,'BAT-B_RDC_BUR-3_NO',NULL,NULL,1,0,93328,5,0,NULL,'°C'),
(29,'rh',1,'BAT-B_RDC_BUR-3_NO',NULL,NULL,1,0,93328,5,0,NULL,'%'),
(30,'temp_12220046',1,'BAT-A_RDC_TEC1_SO',NULL,NULL,1,0,93328,5,0,NULL,'°C'),
(31,'rh',1,'BAT-A_RDC_TEC1_SO',NULL,NULL,1,0,93328,5,0,NULL,'%'),
(32,'temp',1,'BAT-A_RDC_CRS-1_SO',NULL,NULL,1,0,93324,5,0,NULL,'°C'),
(33,'rh',1,'BAT-A_RDC_CRS-1_SO',NULL,NULL,1,0,93324,5,0,NULL,'%'),
(34,'temp',1,'BAT-A_E1_AMPHIBLEU_SO',NULL,NULL,1,0,93324,5,0,NULL,'°C'),
(35,'rh',1,'BAT-A_E1_AMPHIBLEU_SO',NULL,NULL,1,0,93324,5,0,NULL,'%'),
(36,'temp',1,'BAT-A_RDC_CRS-3_N',NULL,NULL,1,0,93320,5,0,NULL,'°C'),
(37,'rh',1,'BAT-A_RDC_CRS-3_N',NULL,NULL,1,0,93320,5,0,NULL,'%'),
(38,'CO2',1,'BAT-A_RDC_AMPHI_NE',NULL,NULL,1,0,31116,5,0,NULL,'ppm'),
(41,'temp_12220827',1,'BAT-B_RDC_BIBLIO_SE',NULL,NULL,1,0,93312,5,0,NULL,'°C'),
(42,'rh',1,'BAT-B_RDC_BIBLIO_SE',NULL,NULL,1,0,93312,5,0,NULL,'%'),
(43,'temp',1,'BAT-A_RDC_TP2_SE',NULL,NULL,1,0,93316,5,0,NULL,'°C'),
(44,'rh',1,'BAT-A_RDC_TP2_SE',NULL,NULL,1,0,93316,5,0,NULL,'%'),
(45,'CO2',1,'BAT-A_RDC_CRS-5_N',NULL,NULL,1,0,31116,5,0,NULL,'ppm'),
(48,'temp',1,'BAT-A_RDC_ACC',NULL,NULL,1,1,93316,5,0,NULL,'°C'),
(49,'rh',1,'BAT-A_RDC_ACC',NULL,NULL,1,1,93316,5,0,NULL,'%'),
(50,'temp_12220849',1,'BAT-B_RDC_BUR-1_NE',NULL,NULL,1,0,93308,5,0,NULL,'°C'),
(51,'rh',1,'BAT-B_RDC_BUR-1_NE',NULL,NULL,1,0,93308,5,0,NULL,'%'),
(52,'_temp',1,'BAT-A_RDC_CRS-5_N',NULL,NULL,1,0,30992,5,0,NULL,'°C'),
(53,'_rh',1,'BAT-A_RDC_CRS-5_N',NULL,NULL,1,0,30992,5,0,NULL,'%'),
(54,'_temp',1,'BAT-C_RDC_CRS-7_NO',NULL,NULL,1,0,30988,5,0,NULL,'°C'),
(55,'_rh',1,'BAT-C_RDC_CRS-7_NO',NULL,NULL,1,0,30988,5,0,NULL,'%'),
(56,'_temp',1,'BAT-A_RDC_AMPHI_NE',NULL,NULL,1,0,30988,5,0,NULL,'°C'),
(57,'_rh',1,'BAT-A_RDC_AMPHI_NE',NULL,NULL,1,0,30988,5,0,NULL,'%'),
(84,'T_Chambre_Froide',1,'AGRIM',NULL,NULL,1,0,16408,5,0,NULL,''),
(62,'OWM',1,'outdoor_temp',NULL,NULL,1,0,691052,5,0,NULL,''),
(101,'T_Préparation_Froide',1,'AGRIM',NULL,NULL,1,0,16392,5,0,NULL,''),
(78,'HR_Préparation_Froide',1,'AGRIM',NULL,NULL,1,0,16392,5,0,NULL,''),
(79,'T_Préparation_Chaude',1,'AGRIM',NULL,NULL,1,0,16400,5,0,NULL,''),
(80,'HR_Préparation_Chaude',1,'AGRIM',NULL,NULL,1,0,16400,5,0,NULL,''),
(82,'T_Légumerie',1,'AGRIM',NULL,NULL,1,0,16400,5,0,NULL,''),
(83,'HR_Légumerie',1,'AGRIM',NULL,NULL,1,0,16400,5,0,NULL,''),
(85,'HR_Chambre_Froide',1,'AGRIM',NULL,NULL,1,0,16408,5,0,NULL,''),
(86,'T_Laverie_Intérieure',1,'AGRIM',NULL,NULL,1,0,16404,5,0,NULL,''),
(87,'HR_Laverie_Intérieure',1,'AGRIM',NULL,NULL,1,0,16404,5,0,NULL,''),
(88,'T_Laverie_Restauration',1,'AGRIM',NULL,NULL,1,0,16308,5,0,NULL,''),
(89,'HR_Laverie_Restauration',1,'AGRIM',NULL,NULL,1,0,16308,5,0,NULL,''),
(91,'HR_Stockage_Alimentaire',1,'AGRIM',NULL,NULL,1,0,16300,5,0,NULL,''),
(100,'T_Stoc_Alim_2',1,'AGRIM',NULL,NULL,1,0,16300,5,0,NULL,''),
(102,'outdoor_temp_C',1,'ACF',NULL,NULL,1,0,NULL,5,0,NULL,''),
(103,'outdoor_humidity_percent',1,'ACF',NULL,NULL,1,0,NULL,5,0,NULL,''),
(104,'outdoor_clouds_all_percent',1,'ACF',NULL,NULL,1,0,NULL,5,0,NULL,'');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT 0,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph`
--

LOCK TABLES `graph` WRITE;
/*!40000 ALTER TABLE `graph` DISABLE KEYS */;
INSERT INTO `graph` VALUES
(1,1,0,'{\"name\":\"LMH_test_25_06_2025\",\"start\":1750837665000,\"end\":1750847730000,\"interval\":15,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":0,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":false,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":30,\"name\":\"temp_12220046\",\"tag\":\"BAT-A_RDC_TEC1_SO\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":28,\"name\":\"temp_12220064\",\"tag\":\"BAT-B_RDC_BUR-3_NO\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":12,\"name\":\"temp_12220777\",\"tag\":\"BAT-C_RDC_BUR-6_NE\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":41,\"name\":\"temp_12220827\",\"tag\":\"BAT-B_RDC_BIBLIO_SE\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":50,\"name\":\"temp_12220849\",\"tag\":\"BAT-B_RDC_BUR-1_NE\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":19,\"name\":\"temp_12220783\",\"tag\":\"BAT-C_RDC_BUR-12_SO\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"1\"}');
/*!40000 ALTER TABLE `graph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `processList` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `input`
--

LOCK TABLES `input` WRITE;
/*!40000 ALTER TABLE `input` DISABLE KEYS */;
INSERT INTO `input` VALUES
(1,1,'OWM','outdoor_temp_C','','1:102',NULL,NULL),
(2,1,'OWM','outdoor_pressure_hPa','','',NULL,NULL),
(3,1,'OWM','outdoor_humidity_percent','','1:103',NULL,NULL),
(4,1,'OWM','outdoor_visibility_m','','',NULL,NULL),
(5,1,'OWM','outdoor_wind_speed_ms','','',NULL,NULL),
(6,1,'OWM','outdoor_wind_deg','','',NULL,NULL),
(7,1,'OWM','outdoor_clouds_all_percent','','1:104',NULL,NULL),
(8,1,'12220757','temp','','',NULL,NULL),
(9,1,'12220757','rh','','',NULL,NULL),
(10,1,'12220757','rssi','','',NULL,NULL),
(11,1,'12220757','battery status','','',NULL,NULL),
(12,1,'12220757','repeated','','',NULL,NULL),
(13,1,'12220770','temp','','',NULL,NULL),
(14,1,'12220770','rh','','',NULL,NULL),
(15,1,'12220770','rssi','','',NULL,NULL),
(16,1,'12220770','battery status','','',NULL,NULL),
(17,1,'12220770','repeated','','',NULL,NULL),
(18,1,'12220767','temp','','',NULL,NULL),
(19,1,'12220767','rh','','',NULL,NULL),
(20,1,'12220767','rssi','','',NULL,NULL),
(21,1,'12220767','battery status','','',NULL,NULL),
(22,1,'12220767','repeated','','',NULL,NULL),
(23,1,'12220777','temp','','',NULL,NULL),
(24,1,'12220777','rh','','',NULL,NULL),
(25,1,'12220777','rssi','','',NULL,NULL),
(26,1,'12220777','battery status','','',NULL,NULL),
(27,1,'12220777','repeated','','',NULL,NULL),
(28,1,'12220041','temp','','',NULL,NULL),
(29,1,'12220041','rh','','',NULL,NULL),
(30,1,'12220041','rssi','','',NULL,NULL),
(31,1,'12220041','battery status','','',NULL,NULL),
(32,1,'12220041','repeated','','',NULL,NULL),
(33,1,'12220762','temp','','',NULL,NULL),
(34,1,'12220762','rh','','',NULL,NULL),
(35,1,'12220762','rssi','','',NULL,NULL),
(36,1,'12220762','battery status','','',NULL,NULL),
(37,1,'12220762','repeated','','',NULL,NULL),
(38,1,'12220783','temp','','',NULL,NULL),
(39,1,'12220783','rh','','',NULL,NULL),
(40,1,'12220783','rssi','','',NULL,NULL),
(41,1,'12220783','battery status','','',NULL,NULL),
(42,1,'12220783','repeated','','',NULL,NULL),
(43,1,'12421037','CO2','','',NULL,NULL),
(44,1,'12421037','temp','','',NULL,NULL),
(45,1,'12421037','rh','','',NULL,NULL),
(46,1,'12421037','rssi','','',NULL,NULL),
(47,1,'12421037','battery status','','',NULL,NULL),
(48,1,'12421037','repeated','','',NULL,NULL),
(150,1,'12220808','temp','','',NULL,NULL),
(49,1,'12220765','temp','','',NULL,NULL),
(50,1,'12220765','rh','','',NULL,NULL),
(51,1,'12220765','rssi','','',NULL,NULL),
(52,1,'12220765','battery status','','',NULL,NULL),
(53,1,'12220765','repeated','','',NULL,NULL),
(54,1,'12220764','temp','','',NULL,NULL),
(55,1,'12220764','rh','','',NULL,NULL),
(56,1,'12220764','rssi','','',NULL,NULL),
(57,1,'12220764','battery status','','',NULL,NULL),
(58,1,'12220764','repeated','','',NULL,NULL),
(59,1,'12220064','temp','','',NULL,NULL),
(60,1,'12220064','rh','','',NULL,NULL),
(61,1,'12220064','rssi','','',NULL,NULL),
(62,1,'12220064','battery status','','',NULL,NULL),
(63,1,'12220064','repeated','','',NULL,NULL),
(64,1,'12220046','temp','','',NULL,NULL),
(65,1,'12220046','rh','','',NULL,NULL),
(66,1,'12220046','rssi','','',NULL,NULL),
(67,1,'12220046','battery status','','',NULL,NULL),
(68,1,'12220046','repeated','','',NULL,NULL),
(69,1,'12211326','temp','','',NULL,NULL),
(70,1,'12211326','rh','','',NULL,NULL),
(71,1,'12211326','rssi','','',NULL,NULL),
(72,1,'12211326','battery status','','',NULL,NULL),
(73,1,'12211326','repeated','','',NULL,NULL),
(74,1,'12211330','temp','','',NULL,NULL),
(75,1,'12211330','rh','','',NULL,NULL),
(76,1,'12211330','rssi','','',NULL,NULL),
(77,1,'12211330','battery status','','',NULL,NULL),
(78,1,'12211330','repeated','','',NULL,NULL),
(79,1,'12211306','temp','','',NULL,NULL),
(80,1,'12211306','rh','','',NULL,NULL),
(81,1,'12211306','rssi','','',NULL,NULL),
(82,1,'12211306','battery status','','',NULL,NULL),
(83,1,'12211306','repeated','','',NULL,NULL),
(84,1,'12421035','CO2','','',NULL,NULL),
(85,1,'12421035','temp','','',NULL,NULL),
(86,1,'12421035','rh','','',NULL,NULL),
(87,1,'12421035','rssi','','',NULL,NULL),
(88,1,'12421035','battery status','','',NULL,NULL),
(89,1,'12421035','repeated','','',NULL,NULL),
(152,1,'12220808','rssi','','',NULL,NULL),
(151,1,'12220808','rh','','',NULL,NULL),
(90,1,'12220827','temp','','',NULL,NULL),
(91,1,'12220827','rh','','',NULL,NULL),
(92,1,'12220827','rssi','','',NULL,NULL),
(93,1,'12220827','battery status','','',NULL,NULL),
(94,1,'12220827','repeated','','',NULL,NULL),
(154,1,'12220808','repeated','','',NULL,NULL),
(95,1,'12220846','temp','','',NULL,NULL),
(96,1,'12220846','rh','','',NULL,NULL),
(97,1,'12220846','rssi','','',NULL,NULL),
(98,1,'12220846','battery status','','',NULL,NULL),
(99,1,'12220846','repeated','','',NULL,NULL),
(100,1,'12421042','CO2','','',NULL,NULL),
(101,1,'12421042','temp','','',NULL,NULL),
(102,1,'12421042','rh','','',NULL,NULL),
(103,1,'12421042','rssi','','',NULL,NULL),
(104,1,'12421042','battery status','','',NULL,NULL),
(105,1,'12421042','repeated','','',NULL,NULL),
(106,1,'12211296','temp','','',NULL,NULL),
(107,1,'12211296','rh','','',NULL,NULL),
(108,1,'12211296','rssi','','',NULL,NULL),
(109,1,'12211296','battery status','','',NULL,NULL),
(110,1,'12211296','repeated','','',NULL,NULL),
(111,1,'12220849','temp','','',NULL,NULL),
(112,1,'12220849','rh','','',NULL,NULL),
(113,1,'12220849','rssi','','',NULL,NULL),
(114,1,'12220849','battery status','','',NULL,NULL),
(115,1,'12220849','repeated','','',NULL,NULL),
(153,1,'12220808','battery status','','',NULL,NULL),
(116,1,'12220806','temp','','',NULL,NULL),
(117,1,'12220806','rh','','',NULL,NULL),
(118,1,'12220806','rssi','','',NULL,NULL),
(119,1,'12220806','battery status','','',NULL,NULL),
(120,1,'12220806','repeated','','',NULL,NULL),
(121,1,'12211339','temp','','',NULL,NULL),
(122,1,'12211339','rh','','',NULL,NULL),
(123,1,'12211339','rssi','','',NULL,NULL),
(124,1,'12211339','battery status','','',NULL,NULL),
(125,1,'12211339','repeated','','',NULL,NULL),
(126,1,'12118481','temp','','',NULL,NULL),
(127,1,'12118481','rssi','','',NULL,NULL),
(128,1,'12118481','battery status','','',NULL,NULL),
(129,1,'12118481','repeated','','',NULL,NULL),
(130,1,'12211211','temp','','',NULL,NULL),
(131,1,'12211211','rh','','',NULL,NULL),
(132,1,'12211211','rssi','','',NULL,NULL),
(133,1,'12211211','battery status','','',NULL,NULL),
(134,1,'12211211','repeated','','',NULL,NULL),
(135,1,'12118016','temp','','',NULL,NULL),
(136,1,'12118016','rssi','','',NULL,NULL),
(137,1,'12118016','battery status','','',NULL,NULL),
(138,1,'12118016','repeated','','',NULL,NULL),
(139,1,'12118119','temp','','',NULL,NULL),
(140,1,'12118119','rssi','','',NULL,NULL),
(141,1,'12118119','battery status','','',NULL,NULL),
(142,1,'12118119','repeated','','',NULL,NULL),
(143,1,'12118215','temp','','',NULL,NULL),
(144,1,'12118215','rssi','','',NULL,NULL),
(145,1,'12118215','battery status','','',NULL,NULL),
(146,1,'12118215','repeated','','',NULL,NULL),
(147,1,'OWM','outdoor_temp','','',NULL,NULL),
(148,1,'bios','test1','','',NULL,NULL),
(149,1,'occupation','test1','','',NULL,NULL);
/*!40000 ALTER TABLE `input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multigraph`
--

DROP TABLE IF EXISTS `multigraph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `multigraph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `feedlist` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multigraph`
--

LOCK TABLES `multigraph` WRITE;
/*!40000 ALTER TABLE `multigraph` DISABLE KEYS */;
INSERT INTO `multigraph` VALUES
(1,'MultiGraph_BAT-A',1,'[{\"id\":\"48\",\"tag\":\"BAT-A_RDC_ACC\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\",\"timeWindow\":604800000,\"detail\":\"basic\"},{\"id\":\"49\",\"tag\":\"BAT-A_RDC_ACC\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\"},{\"id\":\"30\",\"tag\":\"BAT-A_RDC_TEC1_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"31\",\"tag\":\"BAT-A_RDC_TEC1_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"32\",\"tag\":\"BAT-A_RDC_CRS-1_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"33\",\"tag\":\"BAT-A_RDC_CRS-1_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"34\",\"tag\":\"BAT-A_E1_AMPHIBLEU_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"35\",\"tag\":\"BAT-A_E1_AMPHIBLEU_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"36\",\"tag\":\"BAT-A_RDC_CRS-3_N\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"37\",\"tag\":\"BAT-A_RDC_CRS-3_N\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"56\",\"tag\":\"BAT-A_RDC_AMPHI_NE\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"57\",\"tag\":\"BAT-A_RDC_AMPHI_NE\",\"name\":\"_rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"43\",\"tag\":\"BAT-A_RDC_TP2_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"44\",\"tag\":\"BAT-A_RDC_TP2_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"52\",\"tag\":\"BAT-A_RDC_CRS-5_N\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"53\",\"tag\":\"BAT-A_RDC_CRS-5_N\",\"name\":\"_rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"}]'),
(2,'MultiGraph_BAT-B',1,'[{\"id\":\"28\",\"tag\":\"BAT-B_RDC_BUR-3_NO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\",\"timeWindow\":604800000},{\"id\":\"29\",\"tag\":\"BAT-B_RDC_BUR-3_NO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"41\",\"tag\":\"BAT-B_RDC_BIBLIO_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"42\",\"tag\":\"BAT-B_RDC_BIBLIO_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"50\",\"tag\":\"BAT-B_RDC_BUR-1_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"51\",\"tag\":\"BAT-B_RDC_BUR-1_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"}]'),
(3,'MultiGraph_BAT-C',1,'[{\"id\":\"7\",\"tag\":\"BAT-C_RDC_BUR-3_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\",\"timeWindow\":604800000},{\"id\":\"8\",\"tag\":\"BAT-C_RDC_BUR-3_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"9\",\"tag\":\"BAT-C_1ER_BUR-14_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"10\",\"tag\":\"BAT-C_1ER_BUR-14_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"12\",\"tag\":\"BAT-C_RDC_BUR-6_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"13\",\"tag\":\"BAT-C_RDC_BUR-6_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"11\",\"tag\":\"BAT-C_1ER_BUR-27_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"14\",\"tag\":\"BAT-C_1ER_BUR-27_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"15\",\"tag\":\"BAT-C_RDC_CRS-9_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"16\",\"tag\":\"BAT-C_RDC_CRS-9_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"17\",\"tag\":\"BAT-C_RDC_BUR-7_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"18\",\"tag\":\"BAT-C_RDC_BUR-7_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"19\",\"tag\":\"BAT-C_RDC_BUR-12_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"20\",\"tag\":\"BAT-C_RDC_BUR-12_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"54\",\"tag\":\"BAT-C_RDC_CRS-7_NO\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"55\",\"tag\":\"BAT-C_RDC_CRS-7_NO\",\"name\":\"_rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"24\",\"tag\":\"BAT-C_1ER_BUR-22_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\"},{\"id\":\"27\",\"tag\":\"BAT-C_1ER_BUR-22_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\"},{\"id\":\"25\",\"tag\":\"BAT-C_1ER_BUR-21_NO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"804040\"},{\"id\":\"26\",\"tag\":\"BAT-C_1ER_BUR-21_NO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"804040\"}]'),
(4,'MultiGraph_BAT-C_BUR-3',1,'[{\"id\":\"7\",\"tag\":\"BAT-C_RDC_BUR-3_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\",\"timeWindow\":604800000},{\"id\":\"8\",\"tag\":\"BAT-C_RDC_BUR-3_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"004040\"}]'),
(5,'MultiGraph_BAT-C_BUR-14',1,'[{\"id\":\"9\",\"tag\":\"BAT-C_1ER_BUR-14_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"ffff80\"},{\"id\":\"10\",\"tag\":\"BAT-C_1ER_BUR-14_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(7,'MultiGraph_BAT-C_BUR-27',1,'[{\"id\":\"11\",\"tag\":\"BAT-C_1ER_BUR-27_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\",\"timeWindow\":604800000},{\"id\":\"14\",\"tag\":\"BAT-C_1ER_BUR-27_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(8,'MultiGraph_BAT-C_BUR-6',1,'[{\"id\":\"12\",\"tag\":\"BAT-C_RDC_BUR-6_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000},{\"id\":\"13\",\"tag\":\"BAT-C_RDC_BUR-6_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(9,'MultiGraph_BAT-C_CRS-9',1,'[{\"id\":\"15\",\"tag\":\"BAT-C_RDC_CRS-9_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\",\"timeWindow\":604800000},{\"id\":\"16\",\"tag\":\"BAT-C_RDC_CRS-9_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(10,'MultiGraph_BAT-C_BUR-7',1,'[{\"id\":\"17\",\"tag\":\"BAT-C_RDC_BUR-7_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\",\"timeWindow\":604800000},{\"id\":\"18\",\"tag\":\"BAT-C_RDC_BUR-7_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(11,'MultiGraph_BAT-C_BUR-12',1,'[{\"id\":\"19\",\"tag\":\"BAT-C_RDC_BUR-12_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\",\"timeWindow\":604800000},{\"id\":\"20\",\"tag\":\"BAT-C_RDC_BUR-12_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(12,'MultiGraph_BAT-C_CRS-7',1,'[{\"id\":\"54\",\"tag\":\"BAT-C_RDC_CRS-7_NO\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\",\"timeWindow\":604800000},{\"id\":\"18\",\"tag\":\"BAT-C_RDC_BUR-7_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(13,'MultiGraph_BAT-C_BUR-22',1,'[{\"id\":\"24\",\"tag\":\"BAT-C_1ER_BUR-22_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\",\"timeWindow\":604800000},{\"id\":\"27\",\"tag\":\"BAT-C_1ER_BUR-22_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(14,'MultiGraph_BAT-C_BUR-21',1,'[{\"id\":\"25\",\"tag\":\"BAT-C_1ER_BUR-21_NO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"804040\",\"timeWindow\":604800000},{\"id\":\"26\",\"tag\":\"BAT-C_1ER_BUR-21_NO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"804040\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(15,'MultiGraph_BAT-B_BUR-3',1,'[{\"id\":\"28\",\"tag\":\"BAT-B_RDC_BUR-3_NO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\",\"timeWindow\":604800000},{\"id\":\"29\",\"tag\":\"BAT-B_RDC_BUR-3_NO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(16,'MultiGraph_BAT-B_BIBLIO',1,'[{\"id\":\"41\",\"tag\":\"BAT-B_RDC_BIBLIO_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\",\"timeWindow\":604800000},{\"id\":\"42\",\"tag\":\"BAT-B_RDC_BIBLIO_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(17,'MultiGraph_BAT-B_BUR-1',1,'[{\"id\":\"50\",\"tag\":\"BAT-B_RDC_BUR-1_NE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000},{\"id\":\"51\",\"tag\":\"BAT-B_RDC_BUR-1_NE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(18,'Multigraph_BAT-A_TEC1',1,'[{\"id\":\"30\",\"tag\":\"BAT-A_RDC_TEC1_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\",\"timeWindow\":604800000},{\"id\":\"31\",\"tag\":\"BAT-A_RDC_TEC1_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(19,'MultiGraph_BAT-A_CRS-1',1,'[{\"id\":\"32\",\"tag\":\"BAT-A_RDC_CRS-1_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\",\"timeWindow\":604800000},{\"id\":\"33\",\"tag\":\"BAT-A_RDC_CRS-1_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(20,'MultiGraph_BAT-A_AMPHIBLEU',1,'[{\"id\":\"34\",\"tag\":\"BAT-A_E1_AMPHIBLEU_SO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\",\"timeWindow\":604800000},{\"id\":\"35\",\"tag\":\"BAT-A_E1_AMPHIBLEU_SO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(21,'Multigraph_BAT-A_CRS-3',1,'[{\"id\":\"36\",\"tag\":\"BAT-A_RDC_CRS-3_N\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000},{\"id\":\"37\",\"tag\":\"BAT-A_RDC_CRS-3_N\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(22,'MultiGraph_BAT-A_AMPHI',1,'[{\"id\":\"56\",\"tag\":\"BAT-A_RDC_AMPHI_NE\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\",\"timeWindow\":604800000},{\"id\":\"57\",\"tag\":\"BAT-A_RDC_AMPHI_NE\",\"name\":\"_rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(23,'MultiGraph_BAT-A_TP2',1,'[{\"id\":\"43\",\"tag\":\"BAT-A_RDC_TP2_SE\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\",\"timeWindow\":604800000},{\"id\":\"44\",\"tag\":\"BAT-A_RDC_TP2_SE\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(24,'MultiGraph_BAT-A_CRS-5',1,'[{\"id\":\"52\",\"tag\":\"BAT-A_RDC_CRS-5_N\",\"name\":\"_temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\",\"timeWindow\":604800000},{\"id\":\"53\",\"tag\":\"BAT-A_RDC_CRS-5_N\",\"name\":\"_rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(26,'MultiGraph_BAT-A_ACC',1,'[{\"id\":\"48\",\"tag\":\"BAT-A_RDC_ACC\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\",\"timeWindow\":604800000},{\"id\":\"49\",\"tag\":\"BAT-A_RDC_ACC\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080c0\"},{\"id\":\"1\",\"tag\":\"OWM\",\"name\":\"outdoor_temp_C\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"c0c0c0\"},{\"id\":\"3\",\"tag\":\"OWM\",\"name\":\"outdoor_humidity_percent\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),
(38,'Préparation_Froide',1,'[{\"id\":\"101\",\"tag\":\"AGRIM\",\"name\":\"T_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff00\",\"timeWindow\":1993705411.7646484},{\"id\":\"78\",\"tag\":\"AGRIM\",\"name\":\"HR_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff00\"}]'),
(39,'Légumerie',1,'[{\"id\":\"82\",\"tag\":\"AGRIM\",\"name\":\"T_Légumerie\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"004080\",\"timeWindow\":604800000},{\"id\":\"83\",\"tag\":\"AGRIM\",\"name\":\"HR_Légumerie\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8080ff\"}]'),
(48,'Test',1,'[{\"id\":\"77\",\"tag\":\"AGRIM\",\"name\":\"T_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\",\"timeWindow\":604800000},{\"id\":\"78\",\"tag\":\"AGRIM\",\"name\":\"HR_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"}]'),
(40,'Chambre_Froide',1,'[{\"id\":\"84\",\"tag\":\"AGRIM\",\"name\":\"T_Chambre_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"804040\",\"timeWindow\":604800000},{\"id\":\"85\",\"tag\":\"AGRIM\",\"name\":\"HR_Chambre_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8040\"}]'),
(46,'Préparation_Chaude',1,'[{\"id\":\"79\",\"tag\":\"AGRIM\",\"name\":\"T_Préparation_Chaude\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"80ffff\"},{\"id\":\"80\",\"tag\":\"AGRIM\",\"name\":\"HR_Préparation_Chaude\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"}]'),
(42,'Laverie_Intérieure',1,'[{\"id\":\"86\",\"tag\":\"AGRIM\",\"name\":\"T_Laverie_Intérieure\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"808040\",\"timeWindow\":604800000},{\"id\":\"87\",\"tag\":\"AGRIM\",\"name\":\"HR_Laverie_Intérieure\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"808080\"}]'),
(43,'Laverie_Restauration',1,'[{\"id\":\"88\",\"tag\":\"AGRIM\",\"name\":\"T_Laverie_Restauration\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"800080\",\"timeWindow\":604800000},{\"id\":\"89\",\"tag\":\"AGRIM\",\"name\":\"HR_Laverie_Restauration\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0080\"}]'),
(44,'Stockage_Alimentaire',1,'[{\"id\":\"100\",\"tag\":\"AGRIM\",\"name\":\"T_Stoc_Alim_2\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\",\"timeWindow\":604800000},{\"id\":\"91\",\"tag\":\"AGRIM\",\"name\":\"HR_Stockage_Alimentaire\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"008000\"}]'),
(49,'New Multigraph',1,'[{\"id\":\"78\",\"tag\":\"AGRIM\",\"name\":\"HR_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\",\"timeWindow\":604800000},{\"id\":\"101\",\"tag\":\"AGRIM\",\"name\":\"T_Préparation_Froide\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"}]');
/*!40000 ALTER TABLE `multigraph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postprocess`
--

DROP TABLE IF EXISTS `postprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `postprocess` (
  `processid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_updated` int(11) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`processid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postprocess`
--

LOCK TABLES `postprocess` WRITE;
/*!40000 ALTER TABLE `postprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `postprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rememberme`
--

DROP TABLE IF EXISTS `rememberme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rememberme` (
  `userid` int(11) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `persistentToken` varchar(40) DEFAULT NULL,
  `expire` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme`
--

LOCK TABLES `rememberme` WRITE;
/*!40000 ALTER TABLE `rememberme` DISABLE KEYS */;
INSERT INTO `rememberme` VALUES
(1,'494fe5fbe65c122294393da96009469a5b00735a','d2d5a4ada262bc8623e5571da5f488e0e5906142','2025-12-22 05:28:39'),
(1,'e1f43f1c61696b960382a90747739765b231876c','209ff847236fc6eaf0ebcb207bccbcfa9448ebca','2025-12-23 11:09:31');
/*!40000 ALTER TABLE `rememberme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `expression` text DEFAULT NULL,
  `timezone` varchar(64) DEFAULT 'UTC',
  `public` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES
(1,1,'New Schedule','','Europe/Paris',0);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync`
--

DROP TABLE IF EXISTS `sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync` (
  `userid` int(11) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL,
  `auth_with_apikey` int(11) DEFAULT NULL,
  `upload_interval` int(11) DEFAULT NULL,
  `upload_size` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync`
--

LOCK TABLES `sync` WRITE;
/*!40000 ALTER TABLE `sync` DISABLE KEYS */;
INSERT INTO `sync` VALUES
(1,'http://allierhab.ddns.net/obm/emoncms','alexandrecuer','15b82ca56f4f8027928abf3c1b523276','a86b885af35de311872edd3ba2919eaf',0,300,NULL);
/*!40000 ALTER TABLE `sync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_feeds`
--

DROP TABLE IF EXISTS `sync_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_feeds` (
  `userid` int(11) DEFAULT NULL,
  `local_id` int(11) DEFAULT NULL,
  `upload` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_feeds`
--

LOCK TABLES `sync_feeds` WRITE;
/*!40000 ALTER TABLE `sync_feeds` DISABLE KEYS */;
INSERT INTO `sync_feeds` VALUES
(1,1,1),
(1,2,1),
(1,3,1),
(1,4,1),
(1,5,1),
(1,6,1),
(1,7,1),
(1,8,1),
(1,9,1),
(1,10,1),
(1,11,1),
(1,12,1),
(1,13,1),
(1,14,1),
(1,15,1),
(1,16,1),
(1,17,1),
(1,18,1),
(1,19,1),
(1,20,1),
(1,23,1),
(1,24,1),
(1,25,1),
(1,26,1),
(1,27,1),
(1,28,1),
(1,29,1),
(1,30,1),
(1,31,1),
(1,32,1),
(1,33,1),
(1,34,1),
(1,35,1),
(1,36,1),
(1,37,1),
(1,38,1),
(1,41,1),
(1,42,1),
(1,43,1),
(1,44,1),
(1,45,1),
(1,48,1),
(1,49,1),
(1,50,1),
(1,51,1),
(1,52,1),
(1,53,1),
(1,54,1),
(1,55,1),
(1,56,1),
(1,57,1);
/*!40000 ALTER TABLE `sync_feeds` ENABLE KEYS */;
UNLOCK TABLES;


-- Dump completed on 2025-09-25 16:46:28
