-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: emoncms
-- ------------------------------------------------------
-- Server version	10.11.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_config` (
  `userid` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `height` int(11) DEFAULT 600,
  `name` varchar(30) DEFAULT 'no name',
  `alias` varchar(20) DEFAULT '',
  `description` varchar(255) DEFAULT 'no description',
  `main` tinyint(1) DEFAULT 0,
  `public` tinyint(1) DEFAULT 0,
  `published` tinyint(1) DEFAULT 0,
  `showdescription` tinyint(1) DEFAULT 0,
  `backgroundcolor` varchar(6) DEFAULT 'EDF7FC',
  `gridsize` tinyint(1) DEFAULT 20,
  `fullscreen` tinyint(1) DEFAULT 0,
  `feedmode` varchar(8) DEFAULT 'feedid',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
INSERT INTO `dashboard` VALUES
(1,1,'<div id=\"6\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 40px; left: 40px; width: 1040px; height: 360px;\" graphid=\"5\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=5\" style=\"width: 1040px; height: 360px;\" frameborder=\"0\"></iframe></div><div id=\"7\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 420px; left: 40px; width: 1040px; height: 340px;\" graphid=\"6\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=6\" style=\"width: 1040px; height: 340px;\" frameborder=\"0\"></iframe></div><div id=\"8\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 1100px; left: 40px; width: 1040px; height: 320px;\" graphid=\"9\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=9\" style=\"width: 1040px; height: 320px;\" frameborder=\"0\"></iframe></div><div id=\"9\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 1760px; left: 40px; width: 1040px; height: 300px;\" graphid=\"7\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=7\" style=\"width: 1040px; height: 300px;\" frameborder=\"0\"></iframe></div><div id=\"11\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 120px; left: 1160px; width: 100px; height: 40px;\"><a href=\"tempacf\">retour GTB</a></div><div id=\"12\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 760px; left: 60px; width: 1020px; height: 320px;\" graphid=\"8\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=8\" style=\"width: 1020px; height: 320px;\" frameborder=\"0\"></iframe></div><div id=\"13\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 1440px; left: 40px; width: 1040px; height: 300px;\" graphid=\"10\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=10\" style=\"width: 1040px; height: 300px;\" frameborder=\"0\"></iframe></div>',2060,'circuits','circuits','no description',0,1,1,0,'EDF7FC',20,0,'feedid'),
(2,1,'<div id=\"2\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 660px; left: 80px; width: 1000px; height: 300px;\" graphid=\"1\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=1\" style=\"width: 1000px; height: 300px;\" frameborder=\"0\"></iframe></div><div id=\"3\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 980px; left: 80px; width: 1000px; height: 300px;\" graphid=\"2\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=2\" style=\"width: 1000px; height: 300px;\" frameborder=\"0\"></iframe></div><div id=\"4\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 20px; left: 80px; width: 1000px; height: 300px;\" graphid=\"3\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=3\" style=\"width: 1000px; height: 300px;\" frameborder=\"0\"></iframe></div><div id=\"5\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 1300px; left: 80px; width: 1000px; height: 300px;\" graphid=\"4\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=4\" style=\"width: 1000px; height: 300px;\" frameborder=\"0\"></iframe></div><div id=\"6\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 80px; left: 1100px; width: 100px; height: 40px;\"><a href=\"tempacf\">retour GTB</a></div><div id=\"7\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 340px; left: 80px; width: 1000px; height: 300px;\" graphid=\"14\"><iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=14\" style=\"width: 1000px; height: 300px;\" frameborder=\"0\"></iframe></div>',1600,'tintGraphs','tintgraphs','no description',0,1,1,0,'edf7fc',20,0,'feedid'),
(3,1,'<div id=\"79\" class=\"Container-BlueLine\" style=\"position: absolute; margin: 0px; top: 700px; left: 420px; width: 300px; height: 220px;\"></div><div id=\"78\" class=\"Container-BlueLine\" style=\"position: absolute; margin: 0px; top: 700px; left: 20px; width: 360px; height: 220px;\"></div><div id=\"77\" class=\"Container-BlueLine\" style=\"position: absolute; margin: 0px; top: 480px; left: 20px; width: 980px; height: 200px;\"></div><div id=\"37\" class=\"Container-BlueLine\" style=\"position: absolute; margin: 0px; top: 20px; left: 20px; width: 700px; height: 200px;\"></div><div id=\"73\" class=\"Container-BlueLine\" style=\"position: absolute; margin: 0px; top: 240px; left: 20px; width: 940px; height: 220px;\"></div><div id=\"2\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 40px; left: 40px; width: 220px; height: 180px;\" titlethermometer=\"Christophe\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"13\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-2\" width=\"220\" height=\"180\"></canvas><div id=\"can-2-tooltip-1\"></div><div id=\"can-2-tooltip-2\"></div></div><div id=\"6\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 40px; left: 320px; width: 220px; height: 180px;\" titlethermometer=\"Johann\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"21\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"fce94f\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-6\" width=\"220\" height=\"180\"></canvas><div id=\"can-6-tooltip-1\"></div><div id=\"can-6-tooltip-2\"></div></div><div id=\"7\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 40px; width: 120px; height: 180px;\" titlethermometer=\"Catherine\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"19\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-7\" width=\"120\" height=\"180\"></canvas><div id=\"can-7-tooltip-1\"></div><div id=\"can-7-tooltip-2\"></div></div><div id=\"8\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 180px; width: 120px; height: 180px;\" titlethermometer=\"Richard\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"28\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-8\" width=\"120\" height=\"180\"></canvas><div id=\"can-8-tooltip-1\"></div><div id=\"can-8-tooltip-2\"></div></div><div id=\"9\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 500px; left: 40px; width: 200px; height: 180px;\" titlethermometer=\"David B\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"14\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-9\" width=\"200\" height=\"180\"></canvas><div id=\"can-9-tooltip-1\"></div><div id=\"can-9-tooltip-2\"></div></div><div id=\"10\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 500px; left: 260px; width: 200px; height: 180px;\" titlethermometer=\"Mohamed\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"20\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-10\" width=\"200\" height=\"180\"></canvas><div id=\"can-10-tooltip-1\"></div><div id=\"can-10-tooltip-2\"></div></div><div id=\"21\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 720px; left: 40px; width: 200px; height: 180px;\" titlethermometer=\"Adm. Ouest\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"16\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-21\" width=\"200\" height=\"180\"></canvas><div id=\"can-21-tooltip-1\"></div><div id=\"can-21-tooltip-2\"></div></div><div id=\"33\" class=\"Container-Grey\" style=\"position: absolute; margin: 0px; top: 100px; left: 580px; width: 100px; height: 41px;\"></div><div id=\"22\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 720px; left: 440px; width: 160px; height: 180px;\" titlethermometer=\"Adm. Est\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"15\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-22\" width=\"160\" height=\"180\"></canvas><div id=\"can-22-tooltip-1\"></div><div id=\"can-22-tooltip-2\"></div></div><div id=\"34\" class=\"Container-Grey\" style=\"position: absolute; margin: 0px; top: 320px; left: 840px; width: 120px; height: 41px;\"></div><div id=\"26\" class=\"feedvalue\" style=\"position: absolute; margin: 0px; top: 100px; left: 600px; width: 60px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"33\" prepend=\"Sud \" append=\"\" decimals=\"-1\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" size=\"14\" timeout=\"\" errormessagedisplayed=\"\" threshold1=\"\" threshold2=\"\" colour1=\"000000\" colour2=\"000000\" colour3=\"000000\" scale=\"\" align=\"center\">Sud 0</div><div id=\"35\" class=\"Container-Grey\" style=\"position: absolute; margin: 0px; top: 520px; left: 880px; width: 100px; height: 41px;\"></div><div id=\"27\" class=\"feedvalue\" style=\"position: absolute; margin: 0px; top: 320px; left: 840px; width: 120px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"32\" prepend=\"Cellules  \" append=\"\" decimals=\"-1\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" size=\"14\" timeout=\"\" errormessagedisplayed=\"\" threshold1=\"\" threshold2=\"\" colour1=\"000000\" colour2=\"000000\" colour3=\"000000\" scale=\"\" align=\"center\">Cellules  0</div><div id=\"36\" class=\"Container-Grey\" style=\"position: absolute; margin: 0px; top: 800px; left: 240px; width: 120px; height: 41px;\"></div><div id=\"30\" class=\"feedvalue\" style=\"position: absolute; margin: 0px; top: 520px; left: 880px; width: 100px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"37\" prepend=\"Nord \" append=\"\" decimals=\"-1\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" size=\"14\" timeout=\"\" errormessagedisplayed=\"\" threshold1=\"\" threshold2=\"\" colour1=\"000000\" colour2=\"000000\" colour3=\"000000\" scale=\"\" align=\"center\">Nord 0</div><div id=\"31\" class=\"feedvalue\" style=\"position: absolute; margin: 0px; top: 800px; left: 240px; width: 120px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"36\" prepend=\"Ouest \" append=\"\" decimals=\"-1\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" size=\"14\" timeout=\"\" errormessagedisplayed=\"\" threshold1=\"\" threshold2=\"\" colour1=\"000000\" colour2=\"000000\" colour3=\"000000\" scale=\"\" align=\"center\">Ouest 0</div><div id=\"38\" class=\"heading-center\" style=\"position: absolute; margin: 0px; top: 40px; left: 580px; width: 100px; height: 20px;\">chauffage</div><div id=\"42\" class=\"dial\" style=\"position: absolute; margin: 0px; top: 520px; left: 1040px; width: 140px; height: 160px;\" feedid=\"43\" max=\"30\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" decimals=\"-1\" offset=\"\" type=\"22\" graduations=\"1\" unitend=\"0\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-42\" width=\"140\" height=\"160\"></canvas></div><div id=\"46\" class=\"sun\" style=\"position: absolute; margin: 0px; top: 560px; left: 1200px; width: 200px; height: 80px;\" feedid=\"44\" max=\"\" scale=\"\" units_dropdown=\"__other\" units=\"W/m2\" unitend=\"0\" decimals=\"-1\" offset=\"\" solar_title=\"\" colour=\"000000\" font=\"8\" fstyle=\"2\" fweight=\"0\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-46\" width=\"200\" height=\"80\"></canvas></div><div id=\"53\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 500px; left: 1260px; width: 80px; height: 40px;\">Météo</div><div id=\"76\" class=\"Container-Grey\" style=\"position: absolute; margin: 0px; top: 800px; left: 620px; width: 80px; height: 41px;\"></div><div id=\"32\" class=\"feedvalue\" style=\"position: absolute; margin: 0px; top: 800px; left: 640px; width: 60px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"35\" prepend=\"Est \" append=\"\" decimals=\"-1\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" size=\"14\" timeout=\"\" errormessagedisplayed=\"\" threshold1=\"\" threshold2=\"\" colour1=\"000000\" colour2=\"000000\" colour3=\"000000\" scale=\"\" align=\"center\">Est 0</div><div id=\"65\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 180px; left: 420px; width: 60px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"21\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">274s</div><div id=\"66\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 840px; left: 140px; width: 80px; height: 40px; color: rgb(32, 74, 135); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"16\" colour=\"204a87\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">202s</div><div id=\"67\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 180px; left: 140px; width: 80px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"13\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">183s</div><div id=\"68\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 80px; width: 80px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"19\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">208s</div><div id=\"69\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 840px; left: 520px; width: 80px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"15\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">175s</div><div id=\"70\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 240px; width: 80px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"28\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">259s</div><div id=\"71\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 640px; left: 140px; width: 80px; height: 40px; color: rgb(52, 101, 164); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"14\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">5s</div><div id=\"72\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 640px; left: 320px; width: 120px; height: 20px; color: rgb(52, 101, 164); font: bold 18px / 20px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"20\" colour=\"3465a4\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">351s</div><div id=\"74\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 720px; width: 120px; height: 180px;\" titlethermometer=\"Sat. B4\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"22\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-74\" width=\"120\" height=\"180\"></canvas><div id=\"can-74-tooltip-1\"></div><div id=\"can-74-tooltip-2\"></div></div><div id=\"75\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 780px; width: 60px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"22\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">132s</div><div id=\"80\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 40px; left: 980px; width: 40px; height: 40px;\">m3\ngaz</div><div id=\"81\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 280px; left: 980px; width: 60px; height: 40px;\">Temp.\next.\n°C</div><div id=\"82\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 500px; left: 500px; width: 160px; height: 180px;\" titlethermometer=\"David G\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"23\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-82\" width=\"160\" height=\"180\"></canvas><div id=\"can-82-tooltip-1\"></div><div id=\"can-82-tooltip-2\"></div></div><div id=\"83\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 620px; left: 580px; width: 80px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"23\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"\" units=\"\" size=\"14\" unitend=\"0\" align=\"center\">1698162390</div><div id=\"84\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 500px; left: 680px; width: 200px; height: 180px;\" titlethermometer=\"montvenoux\" colourlabel=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"0\" feedid=\"24\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-84\" width=\"200\" height=\"180\"></canvas><div id=\"can-84-tooltip-1\"></div><div id=\"can-84-tooltip-2\"></div></div><div id=\"85\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 620px; left: 760px; width: 80px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" arial=\"\" black\";=\"\" text-align:=\"\" center;\"=\"\" feedid=\"24\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"\" units=\"\" size=\"14\" unitend=\"0\" align=\"center\">58</div><div id=\"90\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 760px; left: 1040px; width: 180px; height: 80px;\"><a href=\"tintgraphs\">graphes de températures intérieures</a></div><div id=\"91\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 780px; left: 780px; width: 220px; height: 80px;\"><a href=\"circuits\">fonctionnement des circuits</a></div><div id=\"93\" class=\"bargraph\" style=\"position: absolute; margin: 0px; top: 0px; left: 1040px; width: 580px; height: 220px;\" feedid=\"27\" colour=\"000000\" colourbg=\"ffffff\" interval=\"d\" units=\"\" dp=\"\" scale=\"\" delta=\"0\" mode=\"0\" initzoom=\"1\"><iframe frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/vis/bargraph?embed=1&feedid=27&colour=000000&colourbg=ffffff&interval=d&units=&dp=&scale=&delta=0&mode=0&initzoom=1\" style=\"width: 580px; height: 220px;\"></iframe></div><div id=\"94\" class=\"graph\" style=\"position: absolute; margin: 0px; top: 220px; left: 1040px; width: 600px; height: 260px;\" graphid=\"13\"><iframe frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/graph/embed&graphid=13\" style=\"width: 600px; height: 260px;\"></iframe></div><div id=\"95\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 320px; width: 140px; height: 180px;\" titlethermometer=\"B302-Bruno\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"59\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-95\" width=\"140\" height=\"180\"></canvas><div id=\"can-95-tooltip-1\"></div><div id=\"can-95-tooltip-2\"></div></div><div id=\"98\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 380px; width: 60px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" feedid=\"59\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">1698162390s</div><div id=\"99\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 480px; width: 120px; height: 180px;\" titlethermometer=\"Corinne\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"60\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-99\" width=\"120\" height=\"180\"></canvas><div id=\"can-99-tooltip-1\"></div><div id=\"can-99-tooltip-2\"></div></div><div id=\"100\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 520px; width: 80px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" feedid=\"60\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"__other\" units=\"s\" size=\"14\" unitend=\"0\" align=\"center\">192s</div><div id=\"101\" class=\"thermometer\" style=\"position: absolute; margin: 0px; top: 260px; left: 600px; width: 120px; height: 180px;\" titlethermometer=\"Sylvain\" colourlabel=\"000000\" font=\"7\" fstyle=\"2\" fweight=\"0\" feedid=\"64\" min=\"14\" max=\"24\" scale=\"\" units_dropdown=\"°C\" units=\"°C\" unitend=\"0\" decimals=\"-1\" offset=\"\" graduations=\"1\" gradnumber=\"5\" displayminmax=\"0\" minvaluefeed=\"18\" maxvaluefeed=\"18\" colourminmax=\"000000\" timeout=\"\" errormessagedisplayed=\"\"><canvas id=\"can-101\" width=\"120\" height=\"180\"></canvas><div id=\"can-101-tooltip-1\"></div><div id=\"can-101-tooltip-2\"></div></div><div id=\"102\" class=\"feedtime\" style=\"position: absolute; margin: 0px; top: 380px; left: 660px; width: 60px; height: 40px; color: rgb(0, 0, 0); font: bold 18px / 40px \"Arial Black\"; text-align: center;\" feedid=\"64\" colour=\"000000\" font=\"9\" fstyle=\"2\" fweight=\"1\" units_dropdown=\"\" units=\"\" size=\"14\" unitend=\"0\" align=\"center\">232</div>',920,'Températures ACF','tempacf','les températures dans les bâtiments de lACF',1,1,1,0,'edf7fc',20,0,'feedid');
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demandshaper`
--

DROP TABLE IF EXISTS `demandshaper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demandshaper` (
  `userid` int(11) DEFAULT NULL,
  `schedules` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demandshaper`
--

LOCK TABLES `demandshaper` WRITE;
/*!40000 ALTER TABLE `demandshaper` DISABLE KEYS */;
/*!40000 ALTER TABLE `demandshaper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `devicekey` varchar(64) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES
(1,1,'Hioki8402','Hioki8402','','','',NULL),
(2,1,'sofrel_Text','sofrel_Text','','','',NULL),
(3,1,'sofrel_Tcascade','sofrel_Tcascade','','','',NULL),
(4,1,'sofrel_Vantage','sofrel_Vantage','','','',NULL),
(5,1,'sofrel_circuit_Cellule','sofrel_circuit_Cellule','','','',NULL),
(6,1,'sofrel_circuit_Nord','sofrel_circuit_Nord','','','',NULL),
(7,1,'sofrel_circuit_Sud','sofrel_circuit_Sud','','','',NULL),
(8,1,'sofrel_circuit_SSHall','sofrel_circuit_SSHall','','','',NULL),
(9,1,'sofrel_circuit_Est','sofrel_circuit_Est','','','',NULL),
(10,1,'sofrel_circuit_Ouest','sofrel_circuit_Ouest','','','',NULL),
(11,1,'TRH12211041_Cellule','TRH12211041_Cellule','','','',NULL),
(12,1,'TRH12211184_Sud','TRH12211184_Sud','','','',NULL),
(13,1,'TRH12211135_Nord','TRH12211135_Nord','','','',NULL),
(14,1,'TRH12211196_Cellule2','TRH12211196_Cellule2','','','',NULL),
(15,1,'sofrel_autopilot','sofrel_autopilot','','','',NULL),
(16,1,'sofrel_courbe_chauffe','sofrel_courbe_chauffe','','','',NULL),
(17,1,'sofrel_courbe_chauffe_admin','sofrel_courbe_chauffe_admin','','','',NULL),
(18,1,'TRH1221206_metroE27','TRH1221206_metroE27','','','',NULL),
(19,1,'TRH12211211_Est','TRH12211211_Est','','','',NULL),
(20,1,'TRH12211290_Ouest','TRH12211290_Ouest','','','',NULL);
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `datatype` int(11) NOT NULL,
  `public` tinyint(1) DEFAULT 0,
  `size` int(11) DEFAULT NULL,
  `engine` int(11) NOT NULL DEFAULT 0,
  `server` int(11) NOT NULL DEFAULT 0,
  `processList` text DEFAULT NULL,
  `unit` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES
(1,'Cellule_Tcircuit',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,35811340,5,0,NULL,''),
(2,'Nord_Tcircuit',1,' sofrel_circuit_Nord',NULL,NULL,1,0,35809224,5,0,NULL,''),
(3,'Sud_Tcircuit',1,' sofrel_circuit_Sud',NULL,NULL,1,0,35809144,5,0,NULL,''),
(4,'Est_Tcircuit',1,'sofrel_circuit_Est',NULL,NULL,1,0,744312,5,0,NULL,''),
(5,'Ouest_Tcircuit',1,'sofrel_circuit_Ouest',NULL,NULL,1,0,744312,5,0,NULL,''),
(6,'OuestTcircuit',1,'PM6RTD',NULL,NULL,1,1,7068608,5,0,NULL,''),
(7,'EstTcircuit',1,'PM6RTD',NULL,NULL,1,1,7068604,5,0,NULL,''),
(8,'NordTcircuit',1,'PM6RTD',NULL,NULL,1,1,7068604,5,0,NULL,''),
(9,'CelluleTcircuit',1,'PM6RTD',NULL,NULL,1,1,7068600,5,0,NULL,''),
(10,'SudTcircuit',1,'PM6RTD',NULL,NULL,1,1,7068100,5,0,NULL,''),
(11,'temp_ext_10s_timestep',1,'davis_vantage',NULL,NULL,1,0,34933724,5,0,NULL,''),
(12,'temp_ext_feb2022_oct2023',1,'davis_vantage',NULL,NULL,1,1,699972,5,0,NULL,''),
(13,'temp',1,'TRH12211184_Sud',NULL,NULL,1,1,1605508,5,0,NULL,''),
(14,'temp',1,'TRH12211135_Nord',NULL,NULL,1,1,1606736,5,0,NULL,''),
(15,'temp',1,'TRH12211211_Est',NULL,NULL,1,1,1151676,5,0,NULL,''),
(16,'temp',1,'TRH12211290_Ouest',NULL,NULL,1,1,1151652,5,0,NULL,''),
(17,'rh',1,'TRH12211196_Cellule2',NULL,NULL,1,1,772740,5,0,NULL,''),
(18,'pulse1',1,'11610946',NULL,NULL,1,1,808508,5,0,NULL,''),
(19,'temp',1,'cathN_12220841',NULL,NULL,1,1,808392,5,0,NULL,''),
(20,'temp',1,'Bureau_Mohamed_12211041',NULL,NULL,1,1,806280,5,0,NULL,''),
(21,'temp',1,'JOHANN_12220822',NULL,NULL,1,1,804792,5,0,NULL,''),
(22,'tempLaurent',1,'12220827',NULL,NULL,1,1,798304,5,0,NULL,''),
(23,'tempDavidG',1,'12220803',NULL,NULL,1,1,616020,5,0,NULL,''),
(24,'tempMontvenoux',1,'12220808',NULL,NULL,1,1,795884,5,0,NULL,''),
(25,'temp',1,'TRH12220806_BURINFO',NULL,NULL,1,1,788664,5,0,NULL,'°C'),
(26,'temp_Eric_C',1,'12118181',NULL,NULL,1,1,765904,5,0,NULL,''),
(59,'temp B302',1,'12118481',NULL,NULL,1,1,301460,5,0,NULL,'°C'),
(27,'m3gazperday',1,'11610946',NULL,NULL,1,1,6228,2,0,NULL,''),
(28,'temp',1,'TRH12211196_Cellule2',NULL,NULL,1,1,1605800,5,0,NULL,''),
(29,'hum',1,'TRH1221206_metroE27',NULL,NULL,1,1,1428288,5,0,NULL,''),
(30,'temp',1,'TRH1221206_metroE27',NULL,NULL,1,1,1428324,5,0,NULL,''),
(31,'ray_sol_mar2022_oct2022',1,'davis_vantage',NULL,NULL,1,1,254436,5,0,NULL,''),
(32,'cells2',1,'bios',NULL,NULL,1,1,896232,5,0,NULL,''),
(33,'sud',1,'bios',NULL,NULL,1,1,896232,5,0,NULL,''),
(40,'regulOncells2',1,'regulations',NULL,NULL,1,1,567724,5,0,NULL,''),
(35,'adm_est',1,'bios',NULL,NULL,1,1,896228,5,0,NULL,''),
(36,'adm_ouest',1,'bios',NULL,NULL,1,1,896228,5,0,NULL,''),
(37,'nord_relay',1,'bios',NULL,NULL,1,1,848756,5,0,NULL,''),
(38,'regulOncells2_bios',1,'regulations',NULL,NULL,1,1,4144440,5,0,NULL,''),
(39,'regulOnnord_relay_bios',1,'regulations',NULL,NULL,1,1,4128180,5,0,NULL,''),
(41,'regulOnnord_relay',1,'regulations',NULL,NULL,1,1,551464,5,0,NULL,''),
(42,'temp',1,'RPI',NULL,NULL,1,0,712860,5,0,NULL,''),
(44,'ray_sol_sep2022_dec2022',1,'davis_vantage',NULL,NULL,1,1,452448,5,0,NULL,''),
(45,'vvent',1,'davis_vantage',NULL,NULL,1,1,452448,5,0,NULL,''),
(46,'pression',1,'davis_vantage',NULL,NULL,1,1,452448,5,0,NULL,''),
(49,'Tcollecteur',1,'sofrel_Tcascade',NULL,NULL,1,1,2070596,5,0,NULL,''),
(50,'Consigne',1,'sofrel_Tcascade',NULL,NULL,1,1,2055964,5,0,NULL,''),
(51,'ConsigneC3',1,'sofrel_Tcascade',NULL,NULL,1,1,2055964,5,0,NULL,''),
(52,'EtatC3',1,'sofrel_Tcascade',NULL,NULL,1,1,2055964,5,0,NULL,''),
(53,'running',1,'pumps',NULL,NULL,1,1,2267592,5,0,NULL,''),
(54,'antifreeze',1,'pumps',NULL,NULL,1,1,2267592,5,0,NULL,''),
(55,'regulonsud',1,'regulations',NULL,NULL,1,1,2267548,5,0,NULL,''),
(56,'regulonadm_ouest',1,'regulations',NULL,NULL,1,1,2267548,5,0,NULL,''),
(57,'regulonadm_est',1,'regulations',NULL,NULL,1,1,2267548,5,0,NULL,''),
(58,'EtatC2',1,'sofrel_Tcascade',NULL,NULL,1,1,2049508,5,0,NULL,''),
(60,'temp Corinne',1,'12220756',NULL,NULL,1,1,376300,5,0,NULL,''),
(61,'rh',1,'TRH12211211_Est',NULL,NULL,1,1,365720,5,0,NULL,'%'),
(62,'rh',1,'TRH12211290_Ouest',NULL,NULL,1,0,365724,5,0,NULL,''),
(63,'rh',1,'TRH12220806_BURINFO',NULL,NULL,1,1,365716,5,0,NULL,'%'),
(64,'temp sylvain',1,'12211339',NULL,NULL,1,1,365000,5,0,NULL,''),
(65,'temp',1,'12346635',NULL,NULL,1,0,339484,5,0,NULL,''),
(66,'temp',1,'12310257',NULL,NULL,1,0,337028,5,0,NULL,''),
(67,'outdoor_temp',1,'OWM',NULL,NULL,1,0,72636,5,0,NULL,''),
(68,'Cellule_Pompe',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,15662032,5,0,NULL,''),
(69,'cellules_TCretourcircuit',1,' sofrel_circuit_Cellule',NULL,NULL,1,0,15661988,5,0,NULL,''),
(70,'Nord_Pompe',1,' sofrel_circuit_Nord',NULL,NULL,1,0,15659916,5,0,NULL,''),
(71,'Nord_TCretourcircuit',1,' sofrel_circuit_Nord',NULL,NULL,1,0,15659900,5,0,NULL,''),
(72,'Sud_Pompe',1,' sofrel_circuit_Sud',NULL,NULL,1,0,15659836,5,0,NULL,''),
(73,'Sud_TCretourcircuit',1,' sofrel_circuit_Sud',NULL,NULL,1,0,15659800,5,0,NULL,''),
(74,'Est_Pompe',1,'sofrel_circuit_Est',NULL,NULL,1,0,72668,5,0,NULL,''),
(75,'Ouest_Pompe',1,'sofrel_circuit_Ouest',NULL,NULL,1,0,72668,5,0,NULL,''),
(76,'Text_nord_cellules',1,'sofrel_text_wired_sensors',NULL,NULL,1,0,15662168,5,0,NULL,''),
(78,'Text_sud_hallssol',1,'sofrel_text_wired_sensors',NULL,NULL,1,0,15662156,5,0,NULL,''),
(80,'Text_est_ouest',1,'sofrel_text_wired_sensors',NULL,NULL,1,0,15662132,5,0,NULL,''),
(82,'ray_sol_dec2019_mar2021',1,'davis_vantage',NULL,NULL,1,0,15662060,5,0,NULL,'');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT 0,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph`
--

LOCK TABLES `graph` WRITE;
/*!40000 ALTER TABLE `graph` DISABLE KEYS */;
INSERT INTO `graph` VALUES
(1,1,0,'{\"name\":\"indoorNord\",\"start\":1667320200000,\"end\":1667927700000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":20,\"name\":\"temp\",\"tag\":\"Bureau_Mohamed_12211041\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":14,\"name\":\"temp\",\"tag\":\"TRH12211135_Nord\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":24,\"name\":\"tempMontvenoux\",\"tag\":\"12220808\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":23,\"name\":\"tempDavidG\",\"tag\":\"12220803\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":26,\"name\":\"temp_Eric_C\",\"tag\":\"12118181\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"1\"}'),
(5,1,0,'{\"name\":\"circuit_cells\",\"start\":1667594640000,\"end\":1667681400000,\"interval\":120,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"100\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":9,\"name\":\"CelluleTcircuit\",\"tag\":\"PM6RTD\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":38,\"name\":\"regulOncells2_bios\",\"tag\":\"regulations\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":\"2\",\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":53,\"name\":\"running\",\"tag\":\"pumps\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"5\"}'),
(2,1,0,'{\"name\":\"indoorSud\",\"start\":1664267400000,\"end\":1664874000000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":21,\"name\":\"temp\",\"tag\":\"JOHANN_12220822\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":13,\"name\":\"temp\",\"tag\":\"TRH12211184_Sud\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"2\"}'),
(3,1,0,'{\"name\":\"indoorCellules\",\"start\":1670242500000,\"end\":1670852700000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":28,\"name\":\"temp\",\"tag\":\"TRH12211196_Cellule2\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":19,\"name\":\"temp\",\"tag\":\"cathN_12220841\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":59,\"name\":\"temp B302\",\"tag\":\"12118481\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":60,\"name\":\"temp Corinne\",\"tag\":\"12220756\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":64,\"name\":\"temp sylvain\",\"tag\":\"12211339\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"3\"}'),
(14,1,0,'{\"name\":\"locaux_noheat\",\"start\":1669304700000,\"end\":1669910400000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":22,\"name\":\"tempLaurent\",\"tag\":\"12220827\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}'),
(4,1,0,'{\"name\":\"indoorAdm\",\"start\":1664267400000,\"end\":1664874000000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":15,\"name\":\"temp\",\"tag\":\"TRH12211211_Est\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":16,\"name\":\"temp\",\"tag\":\"TRH12211290_Ouest\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":25,\"name\":\"tempBureauInfo\",\"tag\":\"12220806\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"4\"}'),
(6,1,0,'{\"name\":\"circuit_nord\",\"start\":1667594640000,\"end\":1667681520000,\"interval\":\"120\",\"mode\":\"interval\",\"limitinterval\":0,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"100\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":8,\"name\":\"NordTcircuit\",\"tag\":\"PM6RTD\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":39,\"name\":\"regulOnnord_relay_bios\",\"tag\":\"regulations\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":\"2\",\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":53,\"name\":\"running\",\"tag\":\"pumps\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"6\"}'),
(7,1,0,'{\"name\":\"production\",\"start\":1667595240000,\"end\":1667681880000,\"interval\":120,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":49,\"name\":\"Tcollecteur\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":1,\"fill\":false,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff0000\"},{\"id\":52,\"name\":\"EtatC3\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":58,\"name\":\"EtatC2\",\"tag\":\"sofrel_Tcascade\",\"yaxis\":2,\"fill\":true,\"scale\":1,\"offset\":0,\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"7\"}'),
(8,1,0,'{\"name\":\"circuit_sud\",\"start\":1667595000000,\"end\":1667681640000,\"interval\":120,\"mode\":\"interval\",\"limitinterval\":1,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"100\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":10,\"name\":\"SudTcircuit\",\"tag\":\"PM6RTD\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":55,\"name\":\"regulonsud\",\"tag\":\"regulations\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":\"2\",\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":53,\"name\":\"running\",\"tag\":\"pumps\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"8\"}'),
(9,1,0,'{\"name\":\"circuit_ouest\",\"start\":1667594880000,\"end\":1667681520000,\"interval\":120,\"mode\":\"interval\",\"limitinterval\":1,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"100\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":6,\"name\":\"OuestTcircuit\",\"tag\":\"PM6RTD\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":56,\"name\":\"regulonadm_ouest\",\"tag\":\"regulations\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":\"2\",\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":53,\"name\":\"running\",\"tag\":\"pumps\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"9\"}'),
(10,1,0,'{\"name\":\"circuit_est\",\"start\":1667594640000,\"end\":1667681400000,\"interval\":120,\"mode\":\"interval\",\"limitinterval\":1,\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"100\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":7,\"name\":\"EstTcircuit\",\"tag\":\"PM6RTD\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true,\"color\":\"#ff8080\"},{\"id\":57,\"name\":\"regulonadm_est\",\"tag\":\"regulations\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":\"2\",\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":53,\"name\":\"running\",\"tag\":\"pumps\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":0,\"average\":0,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"10\"}'),
(11,1,0,'{\"name\":\"m3gazperday\",\"start\":1666821600000,\"end\":1683237600000,\"interval\":\"86400\",\"mode\":\"daily\",\"limitinterval\":0,\"fixinterval\":true,\"floatingtime\":0,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":18,\"name\":\"pulse1\",\"tag\":\"11610946\",\"yaxis\":1,\"fill\":true,\"scale\":\"1\",\"offset\":\"0\",\"delta\":1,\"average\":1,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true}],\"id\":\"11\"}'),
(15,1,0,'{\"name\":\"monthly_conso2022-23\",\"start\":1654034400000,\"end\":1688162400000,\"interval\":\"2592000\",\"mode\":\"monthly\",\"limitinterval\":1,\"fixinterval\":true,\"floatingtime\":0,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":18,\"name\":\"pulse1\",\"tag\":\"11610946\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":1,\"average\":1,\"dp\":0,\"plottype\":\"bars\",\"postprocessed\":true}],\"id\":\"15\"}');
/*!40000 ALTER TABLE `graph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `processList` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `input`
--

LOCK TABLES `input` WRITE;
/*!40000 ALTER TABLE `input` DISABLE KEYS */;
INSERT INTO `input` VALUES
(10,1,'12211290','temp','','1:16',NULL,NULL),
(11,1,'12211290','rh','','1:62',NULL,NULL),
(12,1,'12211290','rssi','','',NULL,NULL),
(13,1,'12211290','battery status','','',NULL,NULL),
(14,1,'12211290','repeated','','',NULL,NULL),
(115,1,'bios','nord_relay','','1:37',NULL,NULL),
(114,1,'bios','sud','','1:33',NULL,NULL),
(121,1,'RPI','temp','','1:42',NULL,NULL),
(20,1,'12220827','temp','','1:22',NULL,NULL),
(21,1,'12220827','rh','','',NULL,NULL),
(22,1,'12220827','rssi','','',NULL,NULL),
(23,1,'12220827','battery status','','',NULL,NULL),
(24,1,'12220827','repeated','','',NULL,NULL),
(135,1,'regulations','regulonadm_ouest','','1:56',NULL,NULL),
(134,1,'regulations','regulonsud','','1:55',NULL,NULL),
(136,1,'regulations','regulonadm_est','','1:57',NULL,NULL),
(161,1,'12220756','temp','','1:60',NULL,NULL),
(160,1,'sofrel_Text','Text_ouest','','',NULL,NULL),
(159,1,'sofrel_Text','Text_est','','',NULL,NULL),
(42,1,'sofrel_vantage','VAN_Text','','47:300,1:12',NULL,NULL),
(158,1,'sofrel_Text','Text_hallssol','','',NULL,NULL),
(157,1,'sofrel_Text','Text_sud','','',NULL,NULL),
(156,1,'sofrel_Text','Text_cellule','','',NULL,NULL),
(155,1,'sofrel_Text','Text_nord','','',NULL,NULL),
(49,1,'12220803','temp','','1:23',NULL,NULL),
(50,1,'12220803','rh','','',NULL,NULL),
(51,1,'12220803','rssi','','',NULL,NULL),
(52,1,'12220803','battery status','','',NULL,NULL),
(53,1,'12220803','repeated','','',NULL,NULL),
(54,1,'12211184','temp','','1:13',NULL,NULL),
(55,1,'12211184','rh','','',NULL,NULL),
(56,1,'12211184','rssi','','',NULL,NULL),
(57,1,'12211184','battery status','','',NULL,NULL),
(58,1,'12211184','repeated','','',NULL,NULL),
(59,1,'12220806','temp','','1:25',NULL,NULL),
(60,1,'12220806','rh','','1:63',NULL,NULL),
(61,1,'12220806','rssi','','',NULL,NULL),
(62,1,'12220806','battery status','','',NULL,NULL),
(63,1,'12220806','repeated','','',NULL,NULL),
(64,1,'12220808','temp','','1:24',NULL,NULL),
(65,1,'12220808','rh','','',NULL,NULL),
(66,1,'12220808','rssi','','',NULL,NULL),
(67,1,'12220808','battery status','','',NULL,NULL),
(68,1,'12220808','repeated','','',NULL,NULL),
(69,1,'12220841','temp','','1:19',NULL,NULL),
(70,1,'12220841','rh','','',NULL,NULL),
(71,1,'12220841','rssi','','',NULL,NULL),
(72,1,'12220841','battery status','','',NULL,NULL),
(73,1,'12220841','repeated','','',NULL,NULL),
(74,1,'12211041','temp','','1:20',NULL,NULL),
(75,1,'12211041','rh','','',NULL,NULL),
(76,1,'12211041','rssi','','',NULL,NULL),
(77,1,'12211041','battery status','','',NULL,NULL),
(78,1,'12211041','repeated','','',NULL,NULL),
(79,1,'12211206','temp','','1:30',NULL,NULL),
(80,1,'12211206','rh','','1:29',NULL,NULL),
(81,1,'12211206','rssi','','',NULL,NULL),
(82,1,'12211206','battery status','','',NULL,NULL),
(83,1,'12211206','repeated','','',NULL,NULL),
(84,1,'12211196','temp','','1:28',NULL,NULL),
(85,1,'12211196','rh','','1:17',NULL,NULL),
(86,1,'12211196','rssi','','',NULL,NULL),
(87,1,'12211196','battery status','','',NULL,NULL),
(88,1,'12211196','repeated','','',NULL,NULL),
(89,1,'12220822','temp','','1:21',NULL,NULL),
(90,1,'12220822','rh','','',NULL,NULL),
(91,1,'12220822','rssi','','',NULL,NULL),
(92,1,'12220822','battery status','','',NULL,NULL),
(93,1,'12220822','repeated','','',NULL,NULL),
(94,1,'12211211','temp','','1:15',NULL,NULL),
(95,1,'12211211','rh','','1:61',NULL,NULL),
(96,1,'12211211','rssi','','',NULL,NULL),
(97,1,'12211211','battery status','','',NULL,NULL),
(98,1,'12211211','repeated','','',NULL,NULL),
(99,1,'12211135','temp','','1:14',NULL,NULL),
(100,1,'12211135','rh','','',NULL,NULL),
(101,1,'12211135','rssi','','',NULL,NULL),
(102,1,'12211135','battery status','','',NULL,NULL),
(103,1,'12211135','repeated','','',NULL,NULL),
(104,1,'12118181','temp','','1:26',NULL,NULL),
(105,1,'12118181','rssi','','',NULL,NULL),
(106,1,'12118181','battery status','','',NULL,NULL),
(107,1,'12118181','repeated','','',NULL,NULL),
(108,1,'11610946','pulse1','','1:18,23:27',NULL,NULL),
(109,1,'11610946','pulse2','','',NULL,NULL),
(110,1,'11610946','rssi','','',NULL,NULL),
(111,1,'11610946','battery status','','',NULL,NULL),
(112,1,'11610946','repeated','','',NULL,NULL),
(116,1,'bios','cells2','','1:32',NULL,NULL),
(117,1,'bios','adm_est','','1:35',NULL,NULL),
(118,1,'bios','adm_ouest','','1:36',NULL,NULL),
(119,1,'regulations','regulonnord_relay','','1:39',NULL,NULL),
(120,1,'regulations','reguloncells2','','1:38',NULL,NULL),
(139,1,'BIOS_vantage','vvent','','1:45',NULL,NULL),
(138,1,'pumps','antifreeze','','1:54',NULL,NULL),
(137,1,'pumps','running','','1:53',NULL,NULL),
(128,1,'PM6RTD','unamed_30002','','49:-3277,1:6',NULL,NULL),
(129,1,'PM6RTD','unamed_30003','','1:7',NULL,NULL),
(130,1,'PM6RTD','unamed_30004','','1:8',NULL,NULL),
(131,1,'PM6RTD','unamed_30005','','1:9',NULL,NULL),
(132,1,'PM6RTD','unamed_30006','','1:10',NULL,NULL),
(133,1,'PM6RTD','unamed_30007','','',NULL,NULL),
(140,1,'BIOS_vantage','pression','','1:46',NULL,NULL),
(141,1,'BIOS_vantage','T_ext','','46:300',NULL,NULL),
(142,1,'BIOS_vantage','T_int','','',NULL,NULL),
(143,1,'BIOS_vantage','HR_int','','',NULL,NULL),
(144,1,'BIOS_vantage','HR_ext','','',NULL,NULL),
(145,1,'BIOS_vantage','UV','','',NULL,NULL),
(146,1,'BIOS_vantage','raySol','','1:44',NULL,NULL),
(148,1,'sofrel_Tcascade','Consigne','','1:50',NULL,NULL),
(147,1,'sofrel_Tcascade','Tcollecteur','','1:49',NULL,NULL),
(149,1,'sofrel_Tcascade','EtatC1','','',NULL,NULL),
(150,1,'sofrel_Tcascade','ConsigneC1','','',NULL,NULL),
(151,1,'sofrel_Tcascade','EtatC2','','1:58',NULL,NULL),
(152,1,'sofrel_Tcascade','ConsigneC2','','',NULL,NULL),
(153,1,'sofrel_Tcascade','EtatC3','','1:52',NULL,NULL),
(154,1,'sofrel_Tcascade','ConsigneC3','','1:51',NULL,NULL),
(162,1,'12220756','rh','','',NULL,NULL),
(163,1,'12220756','rssi','','',NULL,NULL),
(164,1,'12220756','battery status','','',NULL,NULL),
(165,1,'12220756','repeated','','',NULL,NULL),
(166,1,'12118481','temp','','1:59',NULL,NULL),
(167,1,'12118481','rssi','','',NULL,NULL),
(168,1,'12118481','battery status','','',NULL,NULL),
(169,1,'12118481','repeated','','',NULL,NULL),
(170,1,'occupation','cells2','','',NULL,NULL),
(171,1,'occupation','nord_relay','','',NULL,NULL),
(172,1,'occupation','adm_est','','',NULL,NULL),
(173,1,'occupation','sud','','',NULL,NULL),
(174,1,'occupation','adm_ouest','','',NULL,NULL),
(175,1,'12211339','temp','','1:64',NULL,NULL),
(176,1,'12211339','rh','','',NULL,NULL),
(177,1,'12211339','rssi','','',NULL,NULL),
(178,1,'12211339','battery status','','',NULL,NULL),
(179,1,'12211339','repeated','','',NULL,NULL),
(180,1,'OWM','outdoor_temp','','1:67',NULL,NULL),
(181,1,'12346635','temp','','1:65',NULL,NULL),
(182,1,'12346635','rssi','','',NULL,NULL),
(183,1,'12346635','battery status','','',NULL,NULL),
(184,1,'12346635','repeated','','',NULL,NULL),
(185,1,'12310257','temp','','1:66',NULL,NULL),
(186,1,'12310257','rssi','','',NULL,NULL),
(187,1,'12310257','battery status','','',NULL,NULL),
(188,1,'12310257','repeated','','',NULL,NULL);
/*!40000 ALTER TABLE `input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multigraph`
--

DROP TABLE IF EXISTS `multigraph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multigraph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `feedlist` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multigraph`
--

LOCK TABLES `multigraph` WRITE;
/*!40000 ALTER TABLE `multigraph` DISABLE KEYS */;
INSERT INTO `multigraph` VALUES
(1,'metroE27',1,'[{\"id\":\"30\",\"tag\":\"TRH1221206_metroE27\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"6e84f2\"},{\"id\":\"29\",\"tag\":\"TRH1221206_metroE27\",\"name\":\"hum\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"6e84f2\"}]'),
(2,'Admin',1,'[{\"id\":\"25\",\"tag\":\"TRH12220806_BURINFO\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"ff80c0\"},{\"id\":\"63\",\"tag\":\"TRH12220806_BURINFO\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80c0\"},{\"id\":\"15\",\"tag\":\"TRH12211211_Est\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"},{\"id\":\"61\",\"tag\":\"TRH12211211_Est\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"},{\"id\":\"16\",\"tag\":\"TRH12211290_Ouest\",\"name\":\"temp\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"62\",\"tag\":\"TRH12211290_Ouest\",\"name\":\"rh\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"}]');
/*!40000 ALTER TABLE `multigraph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postprocess`
--

DROP TABLE IF EXISTS `postprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postprocess` (
  `userid` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `processid` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) DEFAULT NULL,
  `status_updated` int(11) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`processid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postprocess`
--

LOCK TABLES `postprocess` WRITE;
/*!40000 ALTER TABLE `postprocess` DISABLE KEYS */;
INSERT INTO `postprocess` VALUES
(1,'[]',1,NULL,NULL,NULL,NULL),
(1,NULL,2,'finished',1733477978,'no new data to process','{\"feedA\":31,\"feedB\":44,\"output\":83,\"process_mode\":\"recent\",\"process_start\":0,\"process\":\"mergefeeds\"}'),
(1,NULL,3,'finished',1733478093,'bytes written: 16256, last time value: 1665506400 18','{\"feedA\":31,\"feedB\":44,\"output\":84,\"process_mode\":\"all\",\"process\":\"addfeeds\",\"process_start\":0}');
/*!40000 ALTER TABLE `postprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rememberme`
--

DROP TABLE IF EXISTS `rememberme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme` (
  `userid` int(11) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `persistentToken` varchar(40) DEFAULT NULL,
  `expire` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme`
--

LOCK TABLES `rememberme` WRITE;
/*!40000 ALTER TABLE `rememberme` DISABLE KEYS */;
INSERT INTO `rememberme` VALUES
(1,'860eaab19541dba27ce561da771340dd369f86b5','5d59122c6245b2ab92c4710b96ea4e75f59dfdac','2024-01-22 16:37:26'),
(1,'9084c922d6e84dfdec4b7fbf92cd907a5349448e','3b3a979d94fe377d38f34f7de326637efaa392a4','2023-11-01 09:55:20');
/*!40000 ALTER TABLE `rememberme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `expression` text DEFAULT NULL,
  `timezone` varchar(64) DEFAULT 'UTC',
  `public` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup`
--

DROP TABLE IF EXISTS `setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup` (
  `state` varchar(32) DEFAULT 'unconfigured',
  `wifi` varchar(32) DEFAULT 'unconfigured'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup`
--

LOCK TABLES `setup` WRITE;
/*!40000 ALTER TABLE `setup` DISABLE KEYS */;
INSERT INTO `setup` VALUES
('unconfigured','ethernet');
/*!40000 ALTER TABLE `setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync`
--

DROP TABLE IF EXISTS `sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync` (
  `userid` int(11) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL,
  `auth_with_apikey` int(11) DEFAULT NULL,
  `upload_interval` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync`
--

LOCK TABLES `sync` WRITE;
/*!40000 ALTER TABLE `sync` DISABLE KEYS */;
INSERT INTO `sync` VALUES
(1,'http://172.18.0.3','alexjunk','cce03197414c51aa0d7e0be5a0cdba42','95e5bfc0c7a4dac27dc8e11da1725ace',0,NULL);
/*!40000 ALTER TABLE `sync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_feeds`
--

DROP TABLE IF EXISTS `sync_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync_feeds` (
  `userid` int(11) DEFAULT NULL,
  `local_id` int(11) DEFAULT NULL,
  `upload` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_feeds`
--

LOCK TABLES `sync_feeds` WRITE;
/*!40000 ALTER TABLE `sync_feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_feeds` ENABLE KEYS */;
UNLOCK TABLES;

