-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (armv7l)
--
-- Host: localhost    Database: emoncms
-- ------------------------------------------------------
-- Server version	5.5.59-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_config` (
  `userid` int(11) DEFAULT NULL,
  `data` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` text,
  `height` int(11) DEFAULT '600',
  `name` varchar(30) DEFAULT 'no name',
  `alias` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT 'no description',
  `main` tinyint(1) DEFAULT '0',
  `public` tinyint(1) DEFAULT '0',
  `published` tinyint(1) DEFAULT '0',
  `showdescription` tinyint(1) DEFAULT '0',
  `backgroundcolor` varchar(6) DEFAULT 'EDF7FC',
  `gridsize` tinyint(1) NOT NULL DEFAULT '20',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
INSERT INTO `dashboard` VALUES (1,1,'<div mid=\"1\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 100px; width: 540px; height: 300px;\"><iframe style=\"width: 540px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=1\" frameborder=\"0\"></iframe></div><div id=\"2\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 0px; left: 260px; width: 160px; height: 20px;\">bâtiment technique</div><div mid=\"2\" id=\"3\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 680px; width: 500px; height: 300px;\"><iframe style=\"width: 500px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=2\" frameborder=\"0\"></iframe></div><div id=\"4\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 0px; left: 800px; width: 180px; height: 20px;\">bâtiment administratif</div><div id=\"5\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 680px; width: 20px; height: 20px;\">°C</div><div id=\"6\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 100px; width: 20px; height: 20px;\">°C</div><div id=\"10\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 320px; width: 100px; height: 20px;\">circuit cellule</div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"14\" feedid=\"8\" id=\"11\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 120px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-11\"></canvas></div><div id=\"12\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 160px; width: 80px; height: 20px;\">circuit nord</div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"15\" feedid=\"9\" id=\"14\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 300px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-14\"></canvas></div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"16\" feedid=\"10\" id=\"15\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 480px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-15\"></canvas></div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"17\" feedid=\"11\" id=\"16\" class=\"jgauge2\" style=\"position:absolute; margin: 0; top:360px; left:680px; width:160px; height:160px;\"><canvas height=\"160\" width=\"160\" id=\"can-16\"></canvas></div><div id=\"17\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 520px; width: 100px; height: 20px;\">circuit sud</div><div id=\"18\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-18\"></canvas></div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"18\" feedid=\"12\" id=\"21\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-21\"></canvas></div><div units=\"°C\" min=\"-10\" max=\"100\" scale=\"1\" feedid2=\"19\" feedid=\"13\" id=\"22\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 1040px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-22\"></canvas></div><div id=\"23\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 700px; width: 140px; height: 20px;\">circuit sous-sol &amp; hall</div><div id=\"24\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 900px; width: 80px; height: 20px;\">circuit est</div><div id=\"25\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 1080px; width: 100px; height: 20px;\">circuit ouest</div>',520,'monitoring chaufferie DLCF','chaufferie','no description',0,1,0,0,'edf7fc',20),(4,1,'<div mid=\"3\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=3\" frameborder=\"0\"></iframe></div><div id=\"5\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 360px; left: 80px; width: 50px; height: 50px;\">%</div><div id=\"6\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 50px; left: 1100px; width: 100px; height: 50px;\">°C intérieur</div><div id=\"18\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-18\"></canvas></div><div id=\"26\" class=\"dial\" style=\"position: absolute; margin: 0px; top: 100px; left: 1100px; width: 100px; height: 100px;\" feedid=\"31\" max=\"50\" scale=\"\" units=\"°C\" offset=\"\" type=\"2\" graduations=\"1\"><canvas id=\"can-26\" width=\"100\" height=\"100\"></canvas><div id=\"can-26-tooltip-1\"></div><div id=\"can-26-tooltip-2\"></div></div><div id=\"28\" class=\"dial\" style=\"position: absolute; margin: 0px; top: 240px; left: 1100px; width: 100px; height: 100px;\" feedid=\"26\" max=\"50\" scale=\"\" units=\"°C\" offset=\"\" type=\"2\" graduations=\"1\"><canvas id=\"can-28\" width=\"100\" height=\"100\"></canvas><div id=\"can-28-tooltip-1\"></div><div id=\"can-28-tooltip-2\"></div></div><div id=\"30\" class=\"dial\" style=\"position: absolute; margin: 0px; top: 400px; left: 1100px; width: 100px; height: 100px;\" feedid=\"33\" max=\"50\" scale=\"\" units=\"\" offset=\"\" type=\"2\" graduations=\"1\"><canvas id=\"can-30\" width=\"100\" height=\"100\"></canvas><div id=\"can-30-tooltip-1\"></div><div id=\"can-30-tooltip-2\"></div></div><div id=\"32\" class=\"dial\" style=\"position: absolute; margin: 0px; top: 550px; left: 1100px; width: 100px; height: 90px;\" feedid=\"41\" max=\"50\" scale=\"\" units=\"\" offset=\"\" type=\"2\" graduations=\"1\"><canvas id=\"can-32\" width=\"100\" height=\"90\"></canvas><div id=\"can-32-tooltip-1\"></div><div id=\"can-32-tooltip-2\"></div></div><div id=\"33\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 50px; left: 1100px; width: 100px; height: 50px;\">Chateau</div><div id=\"34\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 200px; left: 1100px; width: 100px; height: 60px;\">ECA</div><div id=\"35\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 350px; left: 1100px; width: 100px; height: 50px;\">SOA</div><div id=\"36\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 500px; left: 1100px; width: 100px; height: 50px;\">GREI (*)</div><div id=\"37\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 250px; left: 900px; width: 150px; height: 50px;\"><p style=\"background-color:white\">Températures</p></div><div mid=\"4\" id=\"40\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 350px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=4\" frameborder=\"0\"></iframe></div><div id=\"38\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 550px; left: 950px; width: 100px; height: 50px;\"><p style=\"background-color:white\">Humidité</p></div><div id=\"39\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 650px; left: 1100px; width: 100px; height: 50px;\">(*) côté brouillard</div><div mid=\"14\" id=\"41\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 700px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=14\" frameborder=\"0\"></iframe></div><div id=\"43\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 700px; left: 50px; width: 50px; height: 50px;\">Confort intérieur\nen\n°C</div><div id=\"44\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 700px; left: 1100px; width: 50px; height: 60px;\">Température\nde\ncircuit \nen °C</div><div id=\"45\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 900px; left: 700px; width: 350px; height: 50px;\"><p style=\"background-color:white\">Fonctionnement du circuit cellule</p></div><div id=\"46\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 50px; left: 50px; width: 50px; height: 50px;\">°C extérieur</div>',1000,'monitoring confort intérieur','Confort','no description',0,1,0,0,'edf7fc',50),(5,1,'<div mid=\"5\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=5\" frameborder=\"0\"></iframe></div><div id=\"5\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 360px; left: 40px; width: 50px; height: 50px;\">Nb resent\npackets</div><div id=\"6\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 40px; width: 50px; height: 50px;\">Nb resent \npackets</div><div id=\"18\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-18\"></canvas></div><div id=\"33\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 0px; left: 1100px; width: 100px; height: 50px;\">millis()</div><div id=\"34\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 360px; left: 1100px; width: 100px; height: 60px;\">millis()</div><div id=\"35\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 680px; left: 1100px; width: 100px; height: 50px;\">millis()</div><div mid=\"7\" id=\"40\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 680px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=7\" frameborder=\"0\"></iframe></div><div id=\"36\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 920px; left: 920px; width: 120px; height: 50px;\">GREI sensor (*)</div><div id=\"37\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 250px; left: 900px; width: 100px; height: 50px;\">ECA sensor</div><div mid=\"6\" id=\"42\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=6\" frameborder=\"0\"></iframe></div><div id=\"38\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 580px; left: 940px; width: 100px; height: 50px;\">SOA sensor</div><div id=\"39\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 940px; left: 1100px; width: 50px; height: 50px;\">(*) côté brouillard</div><div id=\"41\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 680px; left: 40px; width: 60px; height: 60px;\">Nb resent\npackets</div>',990,'statistiques communication','stats','no description',0,1,0,0,'EDF7FC',20),(6,1,'<div mid=\"13\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=13\" frameborder=\"0\"></iframe></div><div id=\"18\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-18\"></canvas></div><div id=\"33\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 0px; left: 1100px; width: 40px; height: 50px;\">°C</div><div id=\"34\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 340px; left: 1100px; width: 40px; height: 40px;\">°C</div><div id=\"35\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 660px; left: 1100px; width: 40px; height: 50px;\">°C</div><div mid=\"11\" id=\"40\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 680px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=11\" frameborder=\"0\"></iframe></div><div id=\"36\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 720px; left: 1120px; width: 80px; height: 50px;\">Régulation du circuit sud</div><div id=\"37\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 60px; left: 1120px; width: 80px; height: 40px;\">Régulation du circuit cellule</div><div mid=\"12\" id=\"42\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 340px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=12\" frameborder=\"0\"></iframe></div><div id=\"38\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 380px; left: 1120px; width: 80px; height: 40px;\">Régulation du circuit nord</div><div mid=\"10\" id=\"43\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 1000px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=10\" frameborder=\"0\"></iframe></div><div mid=\"9\" id=\"44\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 1320px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=9\" frameborder=\"0\"></iframe></div><div id=\"45\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 980px; left: 1100px; width: 40px; height: 60px;\">°C</div><div id=\"46\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 1040px; left: 1120px; width: 80px; height: 60px;\">Régulation du circuit sous-sol hall</div><div id=\"47\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 1300px; left: 1100px; width: 40px; height: 40px;\">°C</div><div id=\"48\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 1360px; left: 1120px; width: 80px; height: 60px;\">Régulation du circuit est</div><div mid=\"8\" id=\"49\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 1640px; left: 100px; width: 1000px; height: 300px;\"><iframe style=\"width: 1000px; height: 300px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=8\" frameborder=\"0\"></iframe></div><div id=\"50\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 1620px; left: 1100px; width: 40px; height: 40px;\">°C</div><div id=\"51\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 1680px; left: 1120px; width: 100px; height: 60px;\">Régulation du circuit ouest</div>',1940,'monitoring_V3V_pompes','v3vpompes','no description',0,1,0,0,'EDF7FC',20),(7,1,'<div mid=\"15\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 160px; width: 1000px; height: 440px;\"><iframe style=\"width: 1000px; height: 440px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=15\" frameborder=\"0\"></iframe></div><div id=\"18\" class=\"jgauge2\" style=\"position: absolute; margin: 0px; top: 360px; left: 860px; width: 160px; height: 160px;\"><canvas height=\"160\" width=\"160\" id=\"can-18\"></canvas></div><div id=\"33\" class=\"heading\" style=\"position: absolute; margin: 0px; top: 0px; left: 1180px; width: 40px; height: 50px;\">°C</div><div id=\"52\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 40px; left: 20px; width: 100px; height: 100px;\"><b>Etats chaudières</b><br>\n1 arrêt<br>\n2 mise en marche<br>\n3 marche<br>\n4 mise à l\'arrêt<br></div>',520,'monitoring_cascade','monicascad','no description',0,1,0,0,'EDF7FC',20),(8,1,'<div mid=\"16\" id=\"1\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 40px; left: 160px; width: 1020px; height: 200px;\"><iframe style=\"width: 1020px; height: 200px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=16\" frameborder=\"0\"></iframe></div><div id=\"2\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 20px; left: 120px; width: 40px; height: 20px;\">T(°C)</div><div mid=\"17\" id=\"3\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 240px; left: 160px; width: 1020px; height: 200px;\"><iframe style=\"width: 1020px; height: 200px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=17\" frameborder=\"0\"></iframe></div><div id=\"4\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 260px; left: 120px; width: 40px; height: 20px;\">HR(%)</div><div mid=\"20\" id=\"5\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 440px; left: 160px; width: 1020px; height: 200px;\"><iframe style=\"width: 1020px; height: 200px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=20\" frameborder=\"0\"></iframe></div><div id=\"6\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 480px; left: 120px; width: 40px; height: 20px;\">hpa</div><div id=\"7\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 500px; left: 1180px; width: 40px; height: 20px;\">km/h</div><div mid=\"18\" id=\"8\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 640px; left: 160px; width: 1020px; height: 200px;\"><iframe style=\"width: 1020px; height: 200px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=18\" frameborder=\"0\"></iframe></div><div id=\"9\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 640px; left: 120px; width: 40px; height: 40px;\">ray\nW/m2</div><div id=\"10\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 640px; left: 1180px; width: 40px; height: 40px;\">UV\nindice</div><div mid=\"19\" id=\"11\" class=\"multigraph\" style=\"position: absolute; margin: 0px; top: 840px; left: 160px; width: 1020px; height: 200px;\"><iframe style=\"width: 1020px; height: 200px;\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"/emoncms/vis/multigraph?embed=1&amp;mid=19\" frameborder=\"0\"></iframe></div><div id=\"12\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 840px; left: 120px; width: 40px; height: 20px;\">mm/h</div><div id=\"13\" class=\"paragraph\" style=\"position: absolute; margin: 0px; top: 840px; left: 1180px; width: 60px; height: 60px;\">niveau cumulé en mm</div>',1040,'monitoring_davis','moniDavis','no description',0,1,0,0,'EDF7FC',20);
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `userid` int(11) DEFAULT NULL,
  `tag` text,
  `time` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `datatype` int(11) NOT NULL,
  `public` tinyint(1) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `engine` int(11) NOT NULL,
  `processList` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (15,'circ_cellule',1,'Node sofrel',NULL,NULL,1,1,15542244,5,NULL),(12,'Text_est',1,'Node sofrel',NULL,NULL,1,1,15542724,5,NULL),(13,'Text_ouest',1,'Node sofrel',NULL,NULL,1,1,15542720,5,NULL),(14,'circ_nord',1,'Node sofrel',NULL,NULL,1,1,15542248,5,NULL),(11,'Text_hallssol',1,'Node sofrel',NULL,NULL,1,1,15542732,5,NULL),(10,'Text_sud',1,'Node sofrel',NULL,NULL,1,1,15542736,5,NULL),(9,'Text_cellule',1,'Node sofrel',NULL,NULL,1,1,15542740,5,NULL),(8,'Text_nord',1,'Node sofrel',NULL,NULL,1,1,15542744,5,NULL),(16,'circ_sud',1,'Node sofrel',NULL,NULL,1,1,15542244,5,NULL),(17,'circ_ssolhall',1,'Node sofrel',NULL,NULL,1,1,15542240,5,NULL),(18,'circ_est',1,'Node sofrel',NULL,NULL,1,1,15542232,5,NULL),(19,'circ_ouest',1,'Node sofrel',NULL,NULL,1,1,15542232,5,NULL),(27,'RH_satellite_ECA',1,'GCM_ECA',NULL,NULL,1,1,3418608,5,NULL),(26,'temp_satellite_ECA',1,'GCM_ECA',NULL,NULL,1,1,3418608,5,NULL),(30,'millis recording',1,'GCM_ECA',NULL,NULL,1,1,3418524,5,NULL),(31,'temp_chateau',1,'chateau',NULL,NULL,1,1,3411756,5,NULL),(32,'RH_chateau',1,'chateau',NULL,NULL,1,1,3411756,5,NULL),(33,'temp1_satellite_GCM_SOA',1,'GCM_SOA',NULL,NULL,1,1,3395480,5,NULL),(34,'temp2_satellite_GCM_SOA',1,'GCM_SOA',NULL,NULL,1,1,3395480,5,NULL),(35,'RH_satellite_B_GCM_SOA',1,'GCM_SOA',NULL,NULL,1,1,3395480,5,NULL),(43,'TH_bureau_sebastienL',1,'GREI_Sebastien',NULL,NULL,1,1,2347388,5,NULL),(42,'temp2_bureau_sebastienL',1,'GREI_Sebastien',NULL,NULL,1,1,2347388,5,NULL),(41,'temp1_bureau_sebastienL',1,'GREI_Sebastien',NULL,NULL,1,1,2347392,5,NULL),(44,'_nbrexmit',1,'Node No1wireBus',NULL,NULL,1,1,9008,5,NULL),(47,'ReSynAck',1,'Node No1wireBus',NULL,NULL,1,1,148896,5,NULL),(52,'timeout',1,'GCM_SOA',NULL,NULL,1,1,3156836,5,NULL),(49,'nbRST',1,'Node No1wireBus',NULL,NULL,1,1,148896,5,NULL),(50,'ReData',1,'Node No1wireBus',NULL,NULL,1,1,148892,5,NULL),(51,'ReFinAck',1,'Node No1wireBus',NULL,NULL,1,1,148892,5,NULL),(53,'ReSynAck',1,'GCM_SOA',NULL,NULL,1,1,3156832,5,NULL),(54,'ReData',1,'GCM_SOA',NULL,NULL,1,1,3156832,5,NULL),(55,'ReFinAck',1,'GCM_SOA',NULL,NULL,1,1,3156832,5,NULL),(91,'Tcollecteur',1,'Node sofrel',NULL,NULL,1,1,5417608,5,NULL),(86,'ReFinAck',1,'GREI_Sebastien',NULL,NULL,1,1,1473156,5,NULL),(93,'Cellule_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414204,5,NULL),(85,'ReData',1,'GREI_Sebastien',NULL,NULL,1,1,1473156,5,NULL),(64,'_millis',1,'GCM_SOA',NULL,NULL,1,1,3111736,5,NULL),(94,'Cellule_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414200,5,NULL),(68,'_millis',1,'GREI_Sebastien',NULL,NULL,1,1,2131932,5,NULL),(66,'_millis',1,'chateau',NULL,NULL,1,1,3115248,5,NULL),(79,'ReSynAck',1,'GCM_ECA',NULL,NULL,1,1,2441708,5,NULL),(80,'ReData',1,'GCM_ECA',NULL,NULL,1,1,2441692,5,NULL),(81,'ReFinAck',1,'GCM_ECA',NULL,NULL,1,1,2441688,5,NULL),(84,'ReSynAck',1,'GREI_Sebastien',NULL,NULL,1,1,1473160,5,NULL),(82,'nbTimeOut',1,'GCM_ECA',NULL,NULL,1,1,2441688,5,NULL),(83,'nbTimeOut',1,'GREI_Sebastien',NULL,NULL,1,1,1473160,5,NULL),(92,'Cellule_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414208,5,NULL),(75,'RcvPkts',1,'GCM_SOA',NULL,NULL,1,1,2937096,5,NULL),(76,'Dropped',1,'GCM_SOA',NULL,NULL,1,1,2937092,5,NULL),(95,'Nord_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414192,5,NULL),(96,'Nord_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414184,5,NULL),(97,'Nord_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414180,5,NULL),(98,'Sud_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414176,5,NULL),(99,'Sud_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414160,5,NULL),(100,'Sud_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414156,5,NULL),(101,'SSHall_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414152,5,NULL),(102,'SSHall_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414152,5,NULL),(103,'SSHal_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414148,5,NULL),(104,'Est_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414136,5,NULL),(105,'Est_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414132,5,NULL),(106,'Est_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414132,5,NULL),(107,'Ouest_Pompe',1,'Node sofrel',NULL,NULL,1,1,5414128,5,NULL),(108,'Ouest_V3V_FER',1,'Node sofrel',NULL,NULL,1,1,5414124,5,NULL),(109,'Ouest_V3V_OUV',1,'Node sofrel',NULL,NULL,1,1,5414120,5,NULL),(110,'node:sofrel:EtatC1',1,'Node sofrel',NULL,NULL,1,1,3209264,5,NULL),(111,'node:sofrel:Consigne',1,'Node sofrel',NULL,NULL,1,1,3209260,5,NULL),(112,'node:sofrel:ConsigneC1',1,'Node sofrel',NULL,NULL,1,1,3209256,5,NULL),(113,'node:sofrel:EtatC2',1,'Node sofrel',NULL,NULL,1,1,3209248,5,NULL),(114,'node:sofrel:ConsigneC2',1,'Node sofrel',NULL,NULL,1,1,3209248,5,NULL),(115,'node:sofrel:VAN_pr_atm',1,'Node sofrel',NULL,NULL,1,1,2959920,5,NULL),(116,'node:sofrel:VAN_T_int',1,'Node sofrel',NULL,NULL,1,1,2959916,5,NULL),(117,'node:sofrel:VAN_HR_int',1,'Node sofrel',NULL,NULL,1,1,2959908,5,NULL),(118,'node:sofrel:VAN_Text',1,'Node sofrel',NULL,NULL,1,1,2959908,5,NULL),(119,'node:sofrel:VAN_HR_ext',1,'Node sofrel',NULL,NULL,1,1,2959904,5,NULL),(120,'node:sofrel:VAN_UV',1,'Node sofrel',NULL,NULL,1,1,2959904,5,NULL),(121,'node:sofrel:VAN_ray_sol',1,'Node sofrel',NULL,NULL,1,1,2959904,5,NULL),(122,'node:sofrel:VAN_precip',1,'Node sofrel',NULL,NULL,1,1,2959900,5,NULL),(123,'node:sofrel:VAN_vitesse_vent',1,'Node sofrel',NULL,NULL,1,1,2952172,5,NULL),(124,'node:sofrel:EtatC3',1,'Node sofrel',NULL,NULL,1,1,126556,5,NULL),(125,'node:sofrel:ConsigneC3',1,'Node sofrel',NULL,NULL,1,1,126532,5,NULL),(126,'node:sofrel:VAN_precip_mmh',1,'Node sofrel',NULL,NULL,1,1,126520,5,NULL),(127,'temp_ext_Escurolles_wunder',1,'Escurolles',NULL,NULL,1,1,125404,5,NULL),(128,'HR_ext_Escurolles_wunder',1,'Escurolles',NULL,NULL,1,1,125284,5,NULL);
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `data` text,
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph`
--

LOCK TABLES `graph` WRITE;
/*!40000 ALTER TABLE `graph` DISABLE KEYS */;
/*!40000 ALTER TABLE `graph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` text,
  `description` text,
  `nodeid` text,
  `processList` text,
  `time` int(10) DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `input`
--

LOCK TABLES `input` WRITE;
/*!40000 ALTER TABLE `input` DISABLE KEYS */;
INSERT INTO `input` VALUES (1,1,'Text_nord','Text_nord','sofrel','1:8',NULL,NULL),(2,1,'Text_cellule','Text_cellule','sofrel','1:9',NULL,NULL),(3,1,'Text_sud','Text_sud','sofrel','1:10',NULL,NULL),(4,1,'Text_hallssol','Text_hallssol','sofrel','1:11',NULL,NULL),(5,1,'Text_est','Text_est','sofrel','1:12',NULL,NULL),(6,1,'Text_ouest','Text_ouest','sofrel','1:13',NULL,NULL),(8,1,'circ_nord','circ_nord','sofrel','1:14',NULL,NULL),(9,1,'circ_cellule','circ_cellule','sofrel','1:15',NULL,NULL),(10,1,'circ_sud','circ_sud','sofrel','1:16',NULL,NULL),(11,1,'circ_ssolhall','circ_ssolhall','sofrel','1:17',NULL,NULL),(12,1,'circ_est','circ_est','sofrel','1:18',NULL,NULL),(13,1,'circ_ouest','circ_ouest','sofrel','1:19',NULL,NULL),(85,1,'ReData','','28_F8_39_9F_6_0_0','1:54',NULL,NULL),(116,1,'ReSynAck','','26_44_94_6_2_0_0','1:79',NULL,NULL),(140,1,'Sud_V3V_OUV','','sofrel','1:100',NULL,NULL),(104,1,'nbTimeOut','','28_F8_39_9F_6_0_0','1:52',NULL,NULL),(84,1,'ReSynAck','','28_F8_39_9F_6_0_0','1:53',NULL,NULL),(137,1,'Nord_V3V_OUV','','sofrel','1:97',NULL,NULL),(138,1,'Sud_Pompe','','sofrel','1:98',NULL,NULL),(139,1,'Sud_V3V_FER','','sofrel','1:99',NULL,NULL),(135,1,'Nord_Pompe','','sofrel','1:95',NULL,NULL),(136,1,'Nord_V3V_FER','','sofrel','1:96',NULL,NULL),(131,1,'Tcollecteur','','sofrel','1:91',NULL,NULL),(132,1,'Cellule_Pompe','','sofrel','1:92',NULL,NULL),(133,1,'Cellule_V3V_FER','','sofrel','1:93',NULL,NULL),(134,1,'Cellule_V3V_OUV','','sofrel','1:94',NULL,NULL),(72,1,'T28_0','SOA','28_F8_39_9F_6_0_0','1:33',NULL,NULL),(73,1,'T26_1','','28_F8_39_9F_6_0_0','1:34',NULL,NULL),(74,1,'RH26_1','','28_F8_39_9F_6_0_0','1:35',NULL,NULL),(91,1,'T26_0','Tchateau','26_37_D4_1_2_0_0','1:31',NULL,NULL),(77,1,'_millis','','28_F8_39_9F_6_0_0','1:64',NULL,NULL),(92,1,'RH26_0','RH chateau','26_37_D4_1_2_0_0','1:32',NULL,NULL),(86,1,'ReFinAck','','28_F8_39_9F_6_0_0','1:55',NULL,NULL),(110,1,'T26_0','ECA','26_44_94_6_2_0_0','1:26',NULL,NULL),(114,1,'RcvPkts','','26_44_94_6_2_0_0','',NULL,NULL),(101,1,'LPort','','28_F8_39_9F_6_0_0','',NULL,NULL),(117,1,'ReData','','26_44_94_6_2_0_0','1:80',NULL,NULL),(99,1,'_millis','','26_37_D4_1_2_0_0','1:66',NULL,NULL),(111,1,'RH26_0','','26_44_94_6_2_0_0','1:27',NULL,NULL),(119,1,'_millis','','26_44_94_6_2_0_0','1:30',NULL,NULL),(118,1,'ReFinAck','','26_44_94_6_2_0_0','1:81',NULL,NULL),(105,1,'RcvPkts','','28_F8_39_9F_6_0_0','1:75',NULL,NULL),(106,1,'Dropped','','28_F8_39_9F_6_0_0','1:76',NULL,NULL),(115,1,'Dropped','','26_44_94_6_2_0_0','',NULL,NULL),(112,1,'LPort','','26_44_94_6_2_0_0','',NULL,NULL),(113,1,'nbTimeOut','','26_44_94_6_2_0_0','1:82',NULL,NULL),(120,1,'T28_0','GREI Sebastien','28_EB_AD_BC_7_0_0','1:41',NULL,NULL),(121,1,'T26_1','','28_EB_AD_BC_7_0_0','1:42',NULL,NULL),(122,1,'RH26_1','','28_EB_AD_BC_7_0_0','1:43',NULL,NULL),(123,1,'LPort','','28_EB_AD_BC_7_0_0','',NULL,NULL),(124,1,'nbTimeOut','','28_EB_AD_BC_7_0_0','1:83',NULL,NULL),(125,1,'RcvPkts','','28_EB_AD_BC_7_0_0','',NULL,NULL),(126,1,'Dropped','','28_EB_AD_BC_7_0_0','',NULL,NULL),(127,1,'ReSynAck','','28_EB_AD_BC_7_0_0','1:84',NULL,NULL),(128,1,'ReData','','28_EB_AD_BC_7_0_0','1:85',NULL,NULL),(129,1,'ReFinAck','','28_EB_AD_BC_7_0_0','1:86',NULL,NULL),(130,1,'_millis','','28_EB_AD_BC_7_0_0','1:68',NULL,NULL),(141,1,'SSHall_Pompe','','sofrel','1:101',NULL,NULL),(142,1,'SSHall_V3V_FER','','sofrel','1:102',NULL,NULL),(143,1,'SSHal_V3V_OUV','','sofrel','1:103',NULL,NULL),(144,1,'Est_Pompe','','sofrel','1:104',NULL,NULL),(145,1,'Est_V3V_FER','','sofrel','1:105',NULL,NULL),(146,1,'Est_V3V_OUV','','sofrel','1:106',NULL,NULL),(147,1,'Ouest_Pompe','','sofrel','1:107',NULL,NULL),(148,1,'Ouest_V3V_FER','','sofrel','1:108',NULL,NULL),(149,1,'Ouest_V3V_OUV','','sofrel','1:109',NULL,NULL),(150,1,'Consigne','','sofrel','1:111',NULL,NULL),(151,1,'EtatC1','','sofrel','1:110',NULL,NULL),(152,1,'ConsigneC1','','sofrel','1:112',NULL,NULL),(153,1,'EtatC2','','sofrel','1:113',NULL,NULL),(154,1,'ConsigneC2','','sofrel','1:114',NULL,NULL),(155,1,'VAN_pr_atm','','sofrel','1:115',NULL,NULL),(156,1,'VAN_T_int','','sofrel','1:116',NULL,NULL),(157,1,'VAN_HR_int','','sofrel','1:117',NULL,NULL),(158,1,'VAN_Text','','sofrel','1:118',NULL,NULL),(159,1,'VAN_HR_ext','','sofrel','1:119',NULL,NULL),(160,1,'VAN_UV','','sofrel','1:120',NULL,NULL),(161,1,'VAN_ray_sol','','sofrel','1:121',NULL,NULL),(162,1,'VAN_precip','','sofrel','1:122',NULL,NULL),(163,1,'VAN_vitesse_vent','','sofrel','1:123',NULL,NULL),(164,1,'temp_ext','','1','1:127',NULL,NULL),(165,1,'HR_ext','','1','1:128',NULL,NULL),(166,1,'EtatC3','','sofrel','1:124',NULL,NULL),(167,1,'ConsigneC3','','sofrel','1:125',NULL,NULL),(168,1,'VAN_precip_mmh','','sofrel','1:126',NULL,NULL);
/*!40000 ALTER TABLE `input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multigraph`
--

DROP TABLE IF EXISTS `multigraph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multigraph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `userid` int(11) DEFAULT NULL,
  `feedlist` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multigraph`
--

LOCK TABLES `multigraph` WRITE;
/*!40000 ALTER TABLE `multigraph` DISABLE KEYS */;
INSERT INTO `multigraph` VALUES (1,'circuits_bat_technique',1,'[{\"id\":\"8\",\"tag\":\"Node sofrel\",\"name\":\"Text_nord\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"5959ff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymax\":\"80\"},{\"id\":\"9\",\"tag\":\"Node sofrel\",\"name\":\"Text_cellule\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\"},{\"id\":\"10\",\"tag\":\"Node sofrel\",\"name\":\"Text_sud\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8888ff\"},{\"id\":\"14\",\"tag\":\"Node sofrel\",\"name\":\"circ_nord\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"15\",\"tag\":\"Node sofrel\",\"name\":\"circ_cellule\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"16\",\"tag\":\"Node sofrel\",\"name\":\"circ_sud\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8040\"}]'),(2,'circuits_chateau',1,'[{\"id\":\"11\",\"tag\":\"Node sofrel\",\"name\":\"Text_hallssol\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymax\":\"80\"},{\"id\":\"12\",\"tag\":\"Node sofrel\",\"name\":\"Text_est\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"9fcfff\"},{\"id\":\"13\",\"tag\":\"Node sofrel\",\"name\":\"Text_ouest\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff80\"},{\"id\":\"17\",\"tag\":\"Node sofrel\",\"name\":\"circ_ssolhall\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"18\",\"tag\":\"Node sofrel\",\"name\":\"circ_est\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"19\",\"tag\":\"Node sofrel\",\"name\":\"circ_ouest\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8040\"}]'),(3,'Temp_int',1,'[{\"id\":\"26\",\"tag\":\"GCM_ECA\",\"name\":\"temp_satellite_ECA\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8000\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"50\",\"y2min\":\"0\",\"y2max\":null},{\"id\":\"31\",\"tag\":\"chateau\",\"name\":\"temp_chateau\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff80\"},{\"id\":\"33\",\"tag\":\"GCM_SOA\",\"name\":\"temp1_satellite_GCM_SOA\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"},{\"id\":\"34\",\"tag\":\"GCM_SOA\",\"name\":\"temp2_satellite_GCM_SOA\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\"},{\"id\":\"41\",\"tag\":\"GREI_Sebastien\",\"name\":\"temp1_bureau_sebastienL\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"42\",\"tag\":\"GREI_Sebastien\",\"name\":\"temp2_bureau_sebastienL\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0080\"},{\"id\":\"10\",\"tag\":\"Node sofrel\",\"name\":\"Text_sud\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"116\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_T_int\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00a600\"}]'),(4,'RH_int',1,'[{\"id\":\"27\",\"tag\":\"GCM_ECA\",\"name\":\"RH_satellite_ECA\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"ff8040\",\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"80\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"32\",\"tag\":\"chateau\",\"name\":\"RH_chateau\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff80\"},{\"id\":\"35\",\"tag\":\"GCM_SOA\",\"name\":\"RH_satellite_B_GCM_SOA\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"},{\"id\":\"43\",\"tag\":\"GREI_Sebastien\",\"name\":\"TH_bureau_sebastienL\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0080\"},{\"id\":\"117\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_HR_int\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"008040\"},{\"id\":\"119\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_HR_ext\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"}]'),(5,'Z_STATS_ECA',1,'[{\"id\":\"30\",\"tag\":\"GCM_ECA\",\"name\":\"millis recording\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":true,\"end\":0,\"skipmissing\":false,\"timeWindow\":86400000},{\"id\":\"79\",\"tag\":\"GCM_ECA\",\"name\":\"ReSynAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"},{\"id\":\"80\",\"tag\":\"GCM_ECA\",\"name\":\"ReData\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8040\"},{\"id\":\"81\",\"tag\":\"GCM_ECA\",\"name\":\"ReFinAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"82\",\"tag\":\"GCM_ECA\",\"name\":\"nbTimeOut\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(6,'Z_STATS_SOA',1,'[{\"id\":\"64\",\"tag\":\"GCM_SOA\",\"name\":\"_millis\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":true,\"end\":0,\"skipmissing\":false,\"timeWindow\":86400000},{\"id\":\"53\",\"tag\":\"GCM_SOA\",\"name\":\"ReSynAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"},{\"id\":\"54\",\"tag\":\"GCM_SOA\",\"name\":\"ReData\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8000\"},{\"id\":\"55\",\"tag\":\"GCM_SOA\",\"name\":\"ReFinAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"52\",\"tag\":\"GCM_SOA\",\"name\":\"timeout\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(7,'Z_STATS_GREI',1,'[{\"id\":\"68\",\"tag\":\"GREI_Sebastien\",\"name\":\"_millis\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":true,\"end\":0,\"skipmissing\":false,\"timeWindow\":86400000},{\"id\":\"84\",\"tag\":\"GREI_Sebastien\",\"name\":\"ReSynAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"},{\"id\":\"85\",\"tag\":\"GREI_Sebastien\",\"name\":\"ReData\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8000\"},{\"id\":\"86\",\"tag\":\"GREI_Sebastien\",\"name\":\"ReFinAck\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"},{\"id\":\"83\",\"tag\":\"GREI_Sebastien\",\"name\":\"nbTimeOut\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(8,'circuit_Ouest',1,'[{\"id\":\"107\",\"tag\":\"Node sofrel\",\"name\":\"Ouest_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"108\",\"tag\":\"Node sofrel\",\"name\":\"Ouest_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"109\",\"tag\":\"Node sofrel\",\"name\":\"Ouest_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"19\",\"tag\":\"Node sofrel\",\"name\":\"circ_ouest\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"13\",\"tag\":\"Node sofrel\",\"name\":\"Text_ouest\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(9,'Circuit_Est',1,'[{\"id\":\"104\",\"tag\":\"Node sofrel\",\"name\":\"Est_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"stacked\":false,\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"105\",\"tag\":\"Node sofrel\",\"name\":\"Est_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"106\",\"tag\":\"Node sofrel\",\"name\":\"Est_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"18\",\"tag\":\"Node sofrel\",\"name\":\"circ_est\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"12\",\"tag\":\"Node sofrel\",\"name\":\"Text_est\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(10,'circuit_SSHALL',1,'[{\"id\":\"101\",\"tag\":\"Node sofrel\",\"name\":\"SSHall_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"102\",\"tag\":\"Node sofrel\",\"name\":\"SSHall_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"103\",\"tag\":\"Node sofrel\",\"name\":\"SSHal_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"17\",\"tag\":\"Node sofrel\",\"name\":\"circ_ssolhall\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"11\",\"tag\":\"Node sofrel\",\"name\":\"Text_hallssol\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(11,'circuit_SUD',1,'[{\"id\":\"98\",\"tag\":\"Node sofrel\",\"name\":\"Sud_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"99\",\"tag\":\"Node sofrel\",\"name\":\"Sud_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"100\",\"tag\":\"Node sofrel\",\"name\":\"Sud_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"16\",\"tag\":\"Node sofrel\",\"name\":\"circ_sud\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"10\",\"tag\":\"Node sofrel\",\"name\":\"Text_sud\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(12,'circuit_nord',1,'[{\"id\":\"95\",\"tag\":\"Node sofrel\",\"name\":\"Nord_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"96\",\"tag\":\"Node sofrel\",\"name\":\"Nord_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"97\",\"tag\":\"Node sofrel\",\"name\":\"Nord_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\",\"stacked\":false},{\"id\":\"14\",\"tag\":\"Node sofrel\",\"name\":\"circ_nord\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"8\",\"tag\":\"Node sofrel\",\"name\":\"Text_nord\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(13,'Circuit_cellule',1,'[{\"id\":\"92\",\"tag\":\"Node sofrel\",\"name\":\"Cellule_Pompe\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ffff\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"1.5\",\"y2min\":\"0\",\"y2max\":\"80\"},{\"id\":\"93\",\"tag\":\"Node sofrel\",\"name\":\"Cellule_V3V_FER\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"94\",\"tag\":\"Node sofrel\",\"name\":\"Cellule_V3V_OUV\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"15\",\"tag\":\"Node sofrel\",\"name\":\"circ_cellule\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"9\",\"tag\":\"Node sofrel\",\"name\":\"Text_cellule\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"}]'),(14,'cellule_TcircuitVSconfort',1,'[{\"id\":\"15\",\"tag\":\"Node sofrel\",\"name\":\"circ_cellule\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"detail\":\"advanced\",\"y2max\":\"80\",\"y2min\":\"0\"},{\"id\":\"33\",\"tag\":\"GCM_SOA\",\"name\":\"temp1_satellite_GCM_SOA\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"34\",\"tag\":\"GCM_SOA\",\"name\":\"temp2_satellite_GCM_SOA\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\"},{\"id\":\"41\",\"tag\":\"GREI_Sebastien\",\"name\":\"temp1_bureau_sebastienL\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8000ff\"},{\"id\":\"42\",\"tag\":\"GREI_Sebastien\",\"name\":\"temp2_bureau_sebastienL\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"8000ff\"}]'),(15,'cascade',1,'[{\"id\":\"110\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:EtatC1\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"c0c0c0\",\"detail\":\"advanced\",\"ymin\":\"0\",\"ymax\":\"5\",\"y2min\":\"-10\",\"y2max\":\"100\"},{\"id\":\"113\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:EtatC2\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8080\"},{\"id\":\"112\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:ConsigneC1\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"000000\"},{\"id\":\"114\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:ConsigneC2\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"11\",\"tag\":\"Node sofrel\",\"name\":\"Text_hallssol\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0000ff\"},{\"id\":\"91\",\"tag\":\"Node sofrel\",\"name\":\"Tcollecteur\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff00\"},{\"id\":\"118\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_Text\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"28a3d7\"},{\"id\":\"124\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:EtatC3\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffcaff\"},{\"id\":\"125\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:ConsigneC3\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff00ff\"},{\"id\":\"111\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:Consigne\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(16,'Davis_TemperaturesVSchaufferie',1,'[{\"id\":\"11\",\"tag\":\"Node sofrel\",\"name\":\"Text_hallssol\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"00ff80\",\"timeWindow\":86400001},{\"id\":\"118\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_Text\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"008000\"},{\"id\":\"116\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_T_int\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\"}]'),(17,'Davis_HR',1,'[{\"id\":\"117\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_HR_int\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff00\",\"timeWindow\":86400000},{\"id\":\"119\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_HR_ext\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"008000\"}]'),(18,'Davis_UV',1,'[{\"id\":\"121\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_ray_sol\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ffff80\",\"timeWindow\":86400000},{\"id\":\"120\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_UV\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8040\"}]'),(19,'Davis_rain',1,'[{\"id\":\"122\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_precip\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8000\",\"timeWindow\":86400000},{\"id\":\"126\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_precip_mmh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":true,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\"}]'),(20,'Davis_PRvsWind',1,'[{\"id\":\"115\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_pr_atm\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"0080ff\",\"timeWindow\":86400000,\"detail\":\"advanced\",\"ymin\":\"800\",\"ymax\":\"1100\"},{\"id\":\"123\",\"tag\":\"Node sofrel\",\"name\":\"node:sofrel:VAN_vitesse_vent\",\"datatype\":\"1\",\"left\":false,\"right\":true,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff8000\"}]'),(21,'Ecurolles',1,'[{\"id\":\"127\",\"tag\":\"Escurolles\",\"name\":\"temp_ext_Escurolles_wunder\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"80ff80\",\"timeWindow\":604800000,\"detail\":\"advanced\",\"graphtype\":\"lineswithsteps\"},{\"id\":\"128\",\"tag\":\"Escurolles\",\"name\":\"HR_ext_Escurolles_wunder\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff80ff\",\"graphtype\":\"lineswithsteps\"}]');
/*!40000 ALTER TABLE `multigraph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rememberme`
--

DROP TABLE IF EXISTS `rememberme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme` (
  `userid` int(11) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `expire` datetime DEFAULT NULL,
  `persistentToken` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme`
--

LOCK TABLES `rememberme` WRITE;
/*!40000 ALTER TABLE `rememberme` DISABLE KEYS */;
INSERT INTO `rememberme` VALUES (1,'8659205c8e4f2845b6773f05da0673de1ff5aa74','2018-03-11 11:31:18','');
/*!40000 ALTER TABLE `rememberme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `expression` text,
  `timezone` varchar(64) DEFAULT 'UTC',
  `public` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setup`
--

DROP TABLE IF EXISTS `setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setup` (
  `state` varchar(32) DEFAULT 'unconfigured',
  `wifi` varchar(32) DEFAULT 'unconfigured'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup`
--

LOCK TABLES `setup` WRITE;
/*!40000 ALTER TABLE `setup` DISABLE KEYS */;
INSERT INTO `setup` VALUES ('unconfigured','ethernet');
/*!40000 ALTER TABLE `setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL,
  `gravatar` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `location` varchar(30) DEFAULT NULL,
  `timezone` varchar(64) DEFAULT 'UTC',
  `language` varchar(5) DEFAULT 'en_EN',
  `bio` text,
  `tags` text,
  `startingpage` varchar(64) NOT NULL DEFAULT 'feed/list',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'alexandrecuer','alexandre.cuer@cerema.fr','73b22acad25afb9f2aaeef9044f7489d37ecc89dd1832cd07abb8801fccd8426','41fc4a076576c0348f8bca5d16d150b6','90e9b4d685c235e62328d56693f45771','c3ea5af65cc7dab2dc271745e3aa019f',NULL,1,'','','Clemront-Ferrand','Europe/Paris','fr_FR','',NULL,'feed/list');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-28 20:39:35
