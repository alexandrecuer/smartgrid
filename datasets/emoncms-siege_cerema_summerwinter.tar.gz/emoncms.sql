-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnueabihf (armv8l)
--
-- Host: localhost    Database: emoncms
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `height` int(11) DEFAULT 600,
  `name` varchar(30) DEFAULT 'no name',
  `alias` varchar(20) DEFAULT '',
  `description` varchar(255) DEFAULT 'no description',
  `main` tinyint(1) DEFAULT 0,
  `public` tinyint(1) DEFAULT 0,
  `published` tinyint(1) DEFAULT 0,
  `showdescription` tinyint(1) DEFAULT 0,
  `backgroundcolor` varchar(6) DEFAULT 'EDF7FC',
  `gridsize` tinyint(1) DEFAULT 20,
  `fullscreen` tinyint(1) DEFAULT 0,
  `feedmode` varchar(8) DEFAULT 'feedid',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `datatype` int(11) NOT NULL,
  `public` tinyint(1) DEFAULT 0,
  `size` int(11) DEFAULT NULL,
  `engine` int(11) NOT NULL DEFAULT 0,
  `server` int(11) NOT NULL DEFAULT 0,
  `processList` text DEFAULT NULL,
  `unit` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (1,'temp_ext',1,'Météo',NULL,NULL,1,0,44364,5,0,NULL,''),(2,'HR_ext',1,'Météo',NULL,NULL,1,0,44364,5,0,NULL,''),(3,'CO2 ppm',1,'Bureau 2205 - 12421037',NULL,NULL,1,0,88068,5,0,NULL,''),(4,'temp',1,'Bureau 2205 - 12421037',NULL,NULL,1,0,88068,5,0,NULL,''),(5,'rh',1,'Bureau 2205 - 12421037',NULL,NULL,1,0,88068,5,0,NULL,''),(15,'temp',1,'Bureau 2221 - 12220764',NULL,NULL,1,0,264132,5,0,NULL,''),(6,'1',1,'Bureau 2205 - Globe',NULL,NULL,1,0,264164,5,0,NULL,''),(11,'rh',1,'Bureau 2204 - 12220797',NULL,NULL,1,0,264136,5,0,NULL,''),(10,'temp',1,'Bureau 2204 - 12220797',NULL,NULL,1,0,264136,5,0,NULL,''),(9,'temp',1,'Bureau 2210 - 12220765',NULL,NULL,1,0,264148,5,0,NULL,''),(12,'rh',1,'Bureau 2210 - 12220765',NULL,NULL,1,0,264148,5,0,NULL,''),(13,'temp',1,'Bureau 2207 - 12220762',NULL,NULL,1,0,264136,5,0,NULL,''),(14,'rh',1,'Bureau 2207 - 12220762',NULL,NULL,1,0,264136,5,0,NULL,''),(16,'rh',1,'Bureau 2221 - 12220764',NULL,NULL,1,0,264132,5,0,NULL,''),(18,'temp',1,'Bureau 2223 - 12220767',NULL,NULL,1,0,264112,5,0,NULL,''),(19,'rh',1,'Bureau 2223 - 12220767',NULL,NULL,1,0,264112,5,0,NULL,''),(20,'temp',1,'Bureau 4104 - 12220770',NULL,NULL,1,0,264104,5,0,NULL,''),(21,'rh',1,'Bureau 4104 - 12220770',NULL,NULL,1,0,264104,5,0,NULL,''),(22,'temp',1,'Bureau 4109 - 12220846',NULL,NULL,1,0,264112,5,0,NULL,''),(23,'rh',1,'Bureau 4109 - 12220846',NULL,NULL,1,0,264112,5,0,NULL,''),(24,'CO2 ppm',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,264088,5,0,NULL,''),(25,'temp',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,264088,5,0,NULL,''),(26,'rh',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,264088,5,0,NULL,''),(27,'temp',1,'Bureau 3211 - jusqu au 30-08-21 - 12220757',NULL,NULL,1,0,119840,5,0,NULL,''),(28,'rh',1,'Bureau 3211 - jusqu au 30-08-21 - 12220757',NULL,NULL,1,0,119840,5,0,NULL,''),(29,'temp',1,'Bureau 4122 - 12220777',NULL,NULL,1,0,264068,5,0,NULL,''),(30,'rh',1,'Bureau 4122 - 12220777',NULL,NULL,1,0,264068,5,0,NULL,''),(31,'CO2 ppm',1,'Bureau 1325 - jusqu au 30-08-21 - 12421035',NULL,NULL,1,0,39976,5,0,NULL,''),(32,'temp',1,'Bureau 4207 - 12220783',NULL,NULL,1,0,264068,5,0,NULL,''),(33,'temp',1,'Bureau 1325 - jusqu au 30-08-21 - 12421035',NULL,NULL,1,0,39976,5,0,NULL,''),(34,'rh',1,'Bureau 1325 - jusqu au 30-08-21 - 12421035',NULL,NULL,1,0,39976,5,0,NULL,''),(35,'rh',1,'Bureau 4207 - 12220783',NULL,NULL,1,0,264068,5,0,NULL,''),(36,'rssi',1,'Bureau 1325 - jusqu au 30-08-21 - 12421035',NULL,NULL,1,0,39976,5,0,NULL,''),(37,'temp',1,'Text - 12310268',NULL,NULL,1,0,264052,5,0,NULL,''),(38,'rssi',1,'Bureau 3211 - jusqu au 30-08-21 - 12220757',NULL,NULL,1,0,119832,5,0,NULL,''),(39,'rssi',1,'Bureau 2207 - 12220762',NULL,NULL,1,0,263988,5,0,NULL,''),(40,'rssi',1,'Bureau 2221 - 12220764',NULL,NULL,1,0,263992,5,0,NULL,''),(41,'rssi',1,'Bureau 2210 - 12220765',NULL,NULL,1,0,263996,5,0,NULL,''),(42,'rssi',1,'Bureau 2223 - 12220767',NULL,NULL,1,0,263992,5,0,NULL,''),(43,'rssi',1,'Bureau 4104 - 12220770',NULL,NULL,1,0,263992,5,0,NULL,''),(44,'rssi',1,'Bureau 4122 - 12220777',NULL,NULL,1,0,263988,5,0,NULL,''),(45,'rssi',1,'Bureau 4207 - 12220783',NULL,NULL,1,0,263996,5,0,NULL,''),(46,'rssi',1,'Bureau 2204 - 12220797',NULL,NULL,1,0,263984,5,0,NULL,''),(47,'rssi',1,'Bureau 4109 - 12220846',NULL,NULL,1,0,263992,5,0,NULL,''),(48,'rssi',1,'Text - 12310268',NULL,NULL,1,0,263988,5,0,NULL,''),(49,'rssi',1,'Bureau 2205 - 12421037',NULL,NULL,1,0,88012,5,0,NULL,''),(50,'rssi',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,88008,5,0,NULL,''),(51,'vitesse_vent',1,'Météo',NULL,NULL,1,0,43480,5,0,NULL,''),(52,'pression',1,'Météo',NULL,NULL,1,0,43480,5,0,NULL,''),(54,'CO2 ppm_15min',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,86912,5,0,NULL,''),(55,'temp_15min',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,86912,5,0,NULL,''),(56,'rh_15min',1,'Bureau 4223 - 12421042',NULL,NULL,1,0,86912,5,0,NULL,''),(57,'rssi_15min',1,'Text - 12310268',NULL,NULL,1,0,86908,5,0,NULL,''),(58,'temp_15min',1,'Text - 12310268',NULL,NULL,1,0,86908,5,0,NULL,''),(59,'rssi',1,'Bureau 4216 - depuis 30-08-2021 - 12220757',NULL,NULL,1,0,144176,5,0,NULL,''),(60,'temp',1,'Bureau 4216 - depuis 30-08-2021 - 12220757',NULL,NULL,1,0,144176,5,0,NULL,''),(61,'rh',1,'Bureau 4216 - depuis 30-08-2021 - 12220757',NULL,NULL,1,0,144176,5,0,NULL,''),(67,'rh',1,'Bureau 4202 - depuis 30-08-2021 - 12421035',NULL,NULL,1,0,45792,5,0,NULL,''),(66,'temp',1,'Bureau 4202 - depuis 30-08-2021 - 12421035',NULL,NULL,1,0,45792,5,0,NULL,''),(65,'rssi',1,'Bureau 4202 - depuis 30-08-2021 - 12421035',NULL,NULL,1,0,45792,5,0,NULL,''),(68,'CO2',1,'Bureau 4202 - depuis 30-08-2021 - 12421035',NULL,NULL,1,0,45792,5,0,NULL,'');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT 0,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph`
--

LOCK TABLES `graph` WRITE;
/*!40000 ALTER TABLE `graph` DISABLE KEYS */;
INSERT INTO `graph` VALUES (6,1,0,'{\"name\":\"batiment 3\",\"start\":1623494700000,\"end\":1624100400000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":27,\"name\":\"temp\",\"tag\":\"Bureau 3211 - 12220757\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":28,\"name\":\"rh\",\"tag\":\"Bureau 3211 - 12220757\",\"yaxis\":2,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}'),(5,1,0,'{\"name\":\"batiment 4\",\"start\":1636350300000,\"end\":1636958700000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":false,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":20,\"name\":\"temp\",\"tag\":\"Bureau 4104 - 12220770\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":22,\"name\":\"temp\",\"tag\":\"Bureau 4109 - 12220846\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":29,\"name\":\"temp\",\"tag\":\"Bureau 4122 - 12220777\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":32,\"name\":\"temp\",\"tag\":\"Bureau 4207 - 12220783\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":55,\"name\":\"temp_15min\",\"tag\":\"Bureau 4223 - 12421042\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":60,\"name\":\"temp\",\"tag\":\"Bureau 4216 - depuis 30-08-2021 - 12220757\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":66,\"name\":\"temp\",\"tag\":\"Bureau 4202 - depuis 30-08-2021 - 12421035\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"5\"}'),(7,1,0,'{\"name\":\"batiment 1\",\"start\":1623493800000,\"end\":1624100400000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":33,\"name\":\"temp\",\"tag\":\"Bureau 1325 - 12421035\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":34,\"name\":\"rh\",\"tag\":\"Bureau 1325 - 12421035\",\"yaxis\":2,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"6\"}'),(3,1,0,'{\"name\":\"batiment 2\",\"start\":1623489300000,\"end\":1624095900000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":4,\"name\":\"temp\",\"tag\":\"Bureau 2205 - 12421037\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":6,\"name\":\"1\",\"tag\":\"Bureau 2205 - Globe\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":9,\"name\":\"temp\",\"tag\":\"Bureau 2210 - 12220765\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":10,\"name\":\"temp\",\"tag\":\"Bureau 2204 - 12220797\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":13,\"name\":\"temp\",\"tag\":\"Bureau 2207 - 12220762\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":15,\"name\":\"temp\",\"tag\":\"Bureau 2021 - 12220764\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":18,\"name\":\"temp\",\"tag\":\"Bureau 2223 - 12220767\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"2\"}'),(8,1,0,'{\"name\":\"meteo\",\"start\":1624562100000,\"end\":1625167800000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":1,\"name\":\"temp_ext\",\"tag\":\"Mto\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":2,\"name\":\"HR_ext\",\"tag\":\"Mto\",\"yaxis\":2,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":58,\"name\":\"temp_15min\",\"tag\":\"Text - 12310268\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":1,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"8\"}'),(13,1,0,'{\"name\":\"CO2\",\"start\":1624882500000,\"end\":1625488200000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":3,\"name\":\"CO2 ppm\",\"tag\":\"Bureau 2205 - 12421037\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":54,\"name\":\"CO2 ppm_15min\",\"tag\":\"Bureau 4223 - 12421042\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":31,\"name\":\"CO2 ppm\",\"tag\":\"Bureau 1325 - 12421035\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}'),(10,1,0,'{\"name\":\"rssiCO2\",\"start\":1623598200000,\"end\":1624203900000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":true,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":49,\"name\":\"rssi\",\"tag\":\"Bureau 2205 - 12421037\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":36,\"name\":\"rssi\",\"tag\":\"Bureau 1325 - 12421035\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":50,\"name\":\"rssi\",\"tag\":\"Bureau 4223 - 12421042\",\"yaxis\":1,\"fill\":0,\"scale\":1,\"offset\":0,\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"\"}'),(11,1,0,'{\"name\":\"rssibat2\",\"start\":1623598200000,\"end\":1624203900000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":false,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":41,\"name\":\"rssi\",\"tag\":\"Bureau 2210 - 12220765\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":46,\"name\":\"rssi\",\"tag\":\"Bureau 2204 - 12220797\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":39,\"name\":\"rssi\",\"tag\":\"Bureau 2207 - 12220762\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":40,\"name\":\"rssi\",\"tag\":\"Bureau 2021 - 12220764\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":42,\"name\":\"rssi\",\"tag\":\"Bureau 2223 - 12220767\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"11\"}'),(12,1,0,'{\"name\":\"rssihorsBat2\",\"start\":1623598200000,\"end\":1624203900000,\"interval\":900,\"mode\":\"interval\",\"fixinterval\":false,\"floatingtime\":1,\"yaxismin\":\"auto\",\"yaxismax\":\"auto\",\"yaxismin2\":\"auto\",\"yaxismax2\":\"auto\",\"showmissing\":false,\"showtag\":true,\"showlegend\":false,\"showcsv\":0,\"csvtimeformat\":\"datestr\",\"csvnullvalues\":\"show\",\"csvheaders\":\"showNameTag\",\"feedlist\":[{\"id\":43,\"name\":\"rssi\",\"tag\":\"Bureau 4104 - 12220770\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":47,\"name\":\"rssi\",\"tag\":\"Bureau 4109 - 12220846\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":38,\"name\":\"rssi\",\"tag\":\"Bureau 3211 - 12220757\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":44,\"name\":\"rssi\",\"tag\":\"Bureau 4122 - 12220777\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":45,\"name\":\"rssi\",\"tag\":\"Bureau 4207 - 12220783\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true},{\"id\":48,\"name\":\"rssi\",\"tag\":\"Text - 12310268\",\"yaxis\":1,\"fill\":0,\"scale\":\"1\",\"offset\":\"0\",\"delta\":false,\"getaverage\":false,\"dp\":0,\"plottype\":\"lines\",\"postprocessed\":true}],\"id\":\"12\"}');
/*!40000 ALTER TABLE `graph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `nodeid` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `processList` text DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=385 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `input`
--

LOCK TABLES `input` WRITE;
/*!40000 ALTER TABLE `input` DISABLE KEYS */;
INSERT INTO `input` VALUES (1,1,'PM6RTD','0','','1:6',NULL,NULL),(2,1,'PM6RTD','1','','',NULL,NULL),(3,1,'emonpi','temp_ext','','1:1',NULL,NULL),(4,1,'emonpi','HR_ext','','1:2',NULL,NULL),(5,1,'12421037','rssi','','1:49',NULL,NULL),(6,1,'12421037','battery status','','',NULL,NULL),(383,1,'12421035','CO2','','1:68',NULL,NULL),(8,1,'12421037','temp','','1:4',NULL,NULL),(9,1,'12421037','rh','','1:5',NULL,NULL),(384,1,'12421035','repeated','','',NULL,NULL),(382,1,'12220757','repeated','','',NULL,NULL),(12,1,'12220762','rssi','','1:39',NULL,NULL),(13,1,'12220762','battery status','','',NULL,NULL),(14,1,'12220762','temp','','1:13',NULL,NULL),(15,1,'12220762','rh','','1:14',NULL,NULL),(16,1,'12220765','rssi','','1:41',NULL,NULL),(17,1,'12220765','battery status','','',NULL,NULL),(18,1,'12220765','temp','','1:9',NULL,NULL),(19,1,'12220765','rh','','1:12',NULL,NULL),(20,1,'12220797','rssi','','1:46',NULL,NULL),(21,1,'12220797','battery status','','',NULL,NULL),(22,1,'12220797','temp','','1:10',NULL,NULL),(23,1,'12220797','rh','','1:11',NULL,NULL),(24,1,'12220764','rssi','','1:40',NULL,NULL),(25,1,'12220764','battery status','','',NULL,NULL),(26,1,'12220764','temp','','1:15',NULL,NULL),(27,1,'12220764','rh','','1:16',NULL,NULL),(28,1,'12220767','rssi','','1:42',NULL,NULL),(29,1,'12220767','battery status','','',NULL,NULL),(30,1,'12220767','temp','','1:18',NULL,NULL),(31,1,'12220767','rh','','1:19',NULL,NULL),(32,1,'12421042','rssi','','1:50',NULL,NULL),(33,1,'12421042','battery status','','',NULL,NULL),(35,1,'12421042','temp','','1:55',NULL,NULL),(36,1,'12421042','rh','','1:56',NULL,NULL),(39,1,'12220846','rssi','','1:47',NULL,NULL),(40,1,'12220846','battery status','','',NULL,NULL),(41,1,'12220846','temp','','1:22',NULL,NULL),(42,1,'12220846','rh','','1:23',NULL,NULL),(43,1,'12220770','rssi','','1:43',NULL,NULL),(44,1,'12220770','battery status','','',NULL,NULL),(45,1,'12220770','temp','','1:20',NULL,NULL),(46,1,'12220770','rh','','1:21',NULL,NULL),(47,1,'12220777','rssi','','1:44',NULL,NULL),(48,1,'12220777','battery status','','',NULL,NULL),(49,1,'12220777','temp','','1:29',NULL,NULL),(50,1,'12220777','rh','','1:30',NULL,NULL),(51,1,'12220783','rssi','','1:45',NULL,NULL),(52,1,'12220783','battery status','','',NULL,NULL),(53,1,'12220783','temp','','1:32',NULL,NULL),(54,1,'12220783','rh','','1:35',NULL,NULL),(55,1,'12310268','rssi','','1:57',NULL,NULL),(56,1,'12310268','battery status','','',NULL,NULL),(57,1,'12310268','temp','','1:58',NULL,NULL),(58,1,'12220757','rssi','','1:59',NULL,NULL),(59,1,'12220757','battery status','','',NULL,NULL),(60,1,'12220757','temp','','1:60',NULL,NULL),(61,1,'12220757','rh','','1:61',NULL,NULL),(62,1,'12421035','rssi','','1:65',NULL,NULL),(63,1,'12421035','battery status','','',NULL,NULL),(65,1,'12421035','temp','','1:66',NULL,NULL),(66,1,'12421035','rh','','1:67',NULL,NULL),(381,1,'12421037','repeated','','',NULL,NULL),(379,1,'12220797','repeated','','',NULL,NULL),(323,1,'emonpi','vitesse_vent','','1:51',NULL,NULL),(324,1,'emonpi','pression','','1:52',NULL,NULL),(380,1,'12421037','CO2','','1:3',NULL,NULL),(365,1,'12220767','repeated','','',NULL,NULL),(369,1,'12220846','repeated','','',NULL,NULL),(370,1,'12220777','repeated','','',NULL,NULL),(371,1,'12220764','repeated','','',NULL,NULL),(372,1,'12220783','repeated','','',NULL,NULL),(373,1,'12220765','repeated','','',NULL,NULL),(374,1,'12220762','repeated','','',NULL,NULL),(375,1,'12220770','repeated','','',NULL,NULL),(376,1,'12310268','repeated','','',NULL,NULL),(377,1,'12421042','CO2','','1:54',NULL,NULL),(378,1,'12421042','repeated','','',NULL,NULL);
/*!40000 ALTER TABLE `input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multigraph`
--

DROP TABLE IF EXISTS `multigraph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multigraph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `feedlist` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multigraph`
--

LOCK TABLES `multigraph` WRITE;
/*!40000 ALTER TABLE `multigraph` DISABLE KEYS */;
INSERT INTO `multigraph` VALUES (3,'Bureau 2210 THR',1,'[{\"id\":\"9\",\"tag\":\"Bureau 2210 - 12220765\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000,\"lineColour\":\"1716ed\"},{\"id\":\"12\",\"tag\":\"Bureau 2210 - 12220765\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"1716ed\"}]'),(2,'Bureau 2205 THR',1,'[{\"id\":\"4\",\"tag\":\"Bureau 2205 - 12421037\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"5\",\"tag\":\"Bureau 2205 - 12421037\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(4,'Bureau 2204 THR',1,'[{\"id\":\"10\",\"tag\":\"Bureau 2204 - 12220797\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"11\",\"tag\":\"Bureau 2204 - 12220797\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(5,'Bureau 2207 THR',1,'[{\"id\":\"13\",\"tag\":\"Bureau 2207 - 12220762\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"14\",\"tag\":\"Bureau 2207 - 12220762\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(6,'Bureau 2223 THR',1,'[{\"id\":\"18\",\"tag\":\"Bureau 2223 - 12220767\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"19\",\"tag\":\"Bureau 2223 - 12220767\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(13,'Bureau 3211 THR',1,'[{\"id\":\"27\",\"tag\":\"Bureau 3211 - 12220757\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"28\",\"tag\":\"Bureau 3211 - 12220757\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(8,'Bureau 2221 THR',1,'[{\"id\":\"15\",\"tag\":\"Bureau 2221 - 12220764\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"16\",\"tag\":\"Bureau 2221 - 12220764\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(9,'Bureau 4104 THR',1,'[{\"id\":\"20\",\"tag\":\"Bureau 4104 - 12220770\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"21\",\"tag\":\"Bureau 4104 - 12220770\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(10,'Bureau 4109 THR',1,'[{\"id\":\"22\",\"tag\":\"Bureau 4109 - 12220846\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"23\",\"tag\":\"Bureau 4109 - 12220846\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(14,'Bureau 4122 THR',1,'[{\"id\":\"29\",\"tag\":\"Bureau 4122 - 12220777\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"30\",\"tag\":\"Bureau 4122 - 12220777\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(12,'Bureau 4223 THR',1,'[{\"id\":\"25\",\"tag\":\"Bureau 4223 - 12421042\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"26\",\"tag\":\"Bureau 4223 - 12421042\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(15,'Bureau 1325 THR',1,'[{\"id\":\"33\",\"tag\":\"Bureau 1325 - 12421035\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"34\",\"tag\":\"Bureau 1325 - 12421035\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(16,'Bureau 4207 THR',1,'[{\"id\":\"32\",\"tag\":\"Bureau 4207 - 12220783\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"timeWindow\":604800000},{\"id\":\"35\",\"tag\":\"Bureau 4207 - 12220783\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true}]'),(19,'Bureaux 2210 2205',1,'[{\"id\":\"4\",\"tag\":\"Bureau 2205 - 12421037\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"090fce\",\"timeWindow\":604800000},{\"id\":\"5\",\"tag\":\"Bureau 2205 - 12421037\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"090fce\"},{\"id\":\"9\",\"tag\":\"Bureau 2210 - 12220765\",\"name\":\"temp\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"},{\"id\":\"12\",\"tag\":\"Bureau 2210 - 12220765\",\"name\":\"rh\",\"datatype\":\"1\",\"left\":true,\"right\":false,\"fill\":false,\"end\":0,\"skipmissing\":true,\"lineColour\":\"ff0000\"}]');
/*!40000 ALTER TABLE `multigraph` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postprocess`
--

DROP TABLE IF EXISTS `postprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postprocess` (
  `userid` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postprocess`
--

LOCK TABLES `postprocess` WRITE;
/*!40000 ALTER TABLE `postprocess` DISABLE KEYS */;
INSERT INTO `postprocess` VALUES (1,'[]');
/*!40000 ALTER TABLE `postprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rememberme`
--

DROP TABLE IF EXISTS `rememberme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme` (
  `userid` int(11) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `persistentToken` varchar(40) DEFAULT NULL,
  `expire` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme`
--

LOCK TABLES `rememberme` WRITE;
/*!40000 ALTER TABLE `rememberme` DISABLE KEYS */;
INSERT INTO `rememberme` VALUES (1,'2408175bdb9e728c7d69fa509c70a59bf520c769','4176079892bb4dc7c37965d6160d3a86b97cba05','2022-03-15 19:59:16'),(1,'b099b2b645d2ceb8c41c11ae1aeaf2a473541124','907b2ea9a882e811bb1fc93eacb068e6ee90eafd','2022-01-10 09:02:20');
/*!40000 ALTER TABLE `rememberme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `expression` text DEFAULT NULL,
  `timezone` varchar(64) DEFAULT 'UTC',
  `public` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync`
--

DROP TABLE IF EXISTS `sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync` (
  `userid` int(11) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync`
--

LOCK TABLES `sync` WRITE;
/*!40000 ALTER TABLE `sync` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  `apikey_write` varchar(64) DEFAULT NULL,
  `apikey_read` varchar(64) DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL,
  `gravatar` varchar(30) DEFAULT '',
  `name` varchar(30) DEFAULT '',
  `location` varchar(30) DEFAULT '',
  `timezone` varchar(64) DEFAULT 'UTC',
  `language` varchar(5) DEFAULT 'en_EN',
  `bio` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `startingpage` varchar(64) DEFAULT 'feed/list',
  `email_verified` int(11) DEFAULT 0,
  `verification_key` varchar(64) DEFAULT '',
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'verdi','alexandre.cuer@cerema.fr','f1f4029ae520554bcedbf825c85f5c30bdf894435373a3c14cddfc387d2c11da','55b38c1209e1e134b26ff569dee18c7c','cb8296ae0f916653caa48fc87a809bad','f0d1f297c91730ac28d419d3e9d56ba0',NULL,1,'','','','Europe/Paris','en_EN',NULL,NULL,'feed/list',0,'',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-02 17:08:25
